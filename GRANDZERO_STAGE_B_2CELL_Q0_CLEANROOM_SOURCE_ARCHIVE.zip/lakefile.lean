import Lake
open Lake DSL

package «gz_stage_b_2cell_q0» where
  leanOptions := #[
    ⟨`autoImplicit, false⟩
  ]

lean_lib «StageA» where
  roots := #[`StageA]

lean_lib «StageB» where
  roots := #[`StageB]

@[default_target]
lean_exe «stage_b_audit» where
  root := `Main
