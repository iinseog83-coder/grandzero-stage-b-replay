import StageB

open GrandZero.StageA
open GrandZero.StageB

structure AuditVectorRow where
  vecId    : String
  expected : TriangleAuditOutcomeQ0
  actual   : TriangleAuditOutcomeQ0
  detail   : String

def runStageBRows : List AuditVectorRow :=
  let r1 := auditTriangle2Cell tb01_spec tb01_witness
  let r2 := auditTriangle2Cell tb02_spec tb02_witness
  let r3 := auditTriangle2Cell tb03_spec tb03_witness
  let r4 := auditTriangle2Cell tb04_spec tb01_witness
  let r5 := auditTriangle2Cell tb05_spec tb05_witness
  let r6 := auditTriangle2Cell tb06_spec tb01_witness
  let degK := match compute2CellDefect tb02_spec with
    | some r => minVarDegPoly 1 r.num
    | none   => none
  let sosOk := checkEmptyOverlapCert tb03_sos_ctx tb03_sos_cert
  [ { vecId    := "TB-01"
      expected := .verifiedExactBridge
      actual   := r1
      detail   := "MolarEnergy_NonVacuousBridge_rho=[10,2,5]_unit=J*mol^-1" },
    { vecId    := "TB-02"
      expected := .verifiedPathDiscrepancy
      actual   := r2
      detail   := s!"TaylorVsNonlinear_rho=[1,1/2]_ordKappa={repr degK}" },
    { vecId    := "TB-03"
      expected := .verifiedEmptyOverlap
      actual   := r3
      detail   := s!"SubsonicSupersonicCone_VacuousBlocked_SOS={sosOk}" },
    { vecId    := "TB-04"
      expected := .rejectedIllTypedOrUnverified .illTypedBridge
      actual   := r4
      detail   := "EnergyVsTorque_KindTagFiberTear_AllWitnessesRejected" },
    { vecId    := "TB-05"
      expected := .verifiedBridgeDomainViolation
      actual   := r5
      detail   := "NonEmptyOverlap_IntermediateGuardPosViolated_rho=[-1]" },
    { vecId    := "TB-06"
      expected := .rejectedIllTypedOrUnverified .authorityEscalation
      actual   := r6
      detail   := "ProductAuthorityLattice_(1,0,0)_to_(1,1,0)_Blocked" } ]

def main : IO UInt32 := do
  IO.println "=================================================================="
  IO.println "GRANDZERO Ω — Stage B (2-Cell Transport) Isolated Kernel Audit"
  IO.println "=================================================================="
  let rows := runStageBRows
  let mut allOk := true
  for row in rows do
    let ok := row.expected == row.actual
    if !ok then
      allOk := false
    IO.println s!"VECTOR|ID={row.vecId}|EXPECTED={formatOutcome row.expected}|ACTUAL={formatOutcome row.actual}|MATCH={ok}|DETAIL={row.detail}"
  let sosOk := checkEmptyOverlapCert tb03_sos_ctx tb03_sos_cert
  let defectDegOk := (match compute2CellDefect tb02_spec with | some r => minVarDegPoly 1 r.num == some 2 | none => false)
  if !(sosOk && defectDegOk) then
    allOk := false
  IO.println s!"EXTRA|ID=TB-02-DEFECT|KAPPA_MIN_DEG_2={defectDegOk}|NEG_V_COUNTEREXAMPLE_PROVED=true|NONNEG_BOUND_PROVED=true"
  IO.println s!"EXTRA|ID=TB-03-SOS|NONLINEAR_SQUARE_EMPTY_OVERLAP={sosOk}"
  IO.println "------------------------------------------------------------------"
  IO.println s!"ALL STAGE B ADVERSARIAL & 2-CELL VECTORS MATCH EXPECTED: {allOk}"
  IO.println "=================================================================="
  return if allOk then 0 else 1
