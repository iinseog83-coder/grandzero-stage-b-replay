/-
  GRANDZERO Ω — Stage A (M1-P0 R3) Isolated Kernel
  Module A-1: Q0SyntaxAndUnits.lean
  Scope: 7D SI Dimensions, QuantityKind Fiber, De Bruijn Syntax, Scoping,
         Static Unit Synthesis, Lifting, Substitution, and LEM-SubstUnit.
-/

namespace GrandZero.StageA

/-- 7-dimensional coherent SI base exponent vector (L, M, T, I, Θ, N, J). -/
structure DimVec7 where
  L  : Int := 0
  M  : Int := 0
  T  : Int := 0
  I  : Int := 0
  Th : Int := 0
  N  : Int := 0
  J  : Int := 0
  deriving DecidableEq, Repr, Inhabited

namespace DimVec7

def zero : DimVec7 := {}

def add (a b : DimVec7) : DimVec7 :=
  { L := a.L + b.L
    M := a.M + b.M
    T := a.T + b.T
    I := a.I + b.I
    Th := a.Th + b.Th
    N := a.N + b.N
    J := a.J + b.J }

def sub (a b : DimVec7) : DimVec7 :=
  { L := a.L - b.L
    M := a.M - b.M
    T := a.T - b.T
    I := a.I - b.I
    Th := a.Th - b.Th
    N := a.N - b.N
    J := a.J - b.J }

def neg (a : DimVec7) : DimVec7 :=
  { L := -a.L
    M := -a.M
    T := -a.T
    I := -a.I
    Th := -a.Th
    N := -a.N
    J := -a.J }

end DimVec7

/-- Physical quantity ontology tag separating iso-dimensional distinct kinds
    (e.g., Energy [J] vs Torque [N·m], Dimensionless scalar vs PlaneAngle [rad]). -/
inductive KindTagQ0 where
  | canonical : KindTagQ0
  | torque    : KindTagQ0
  | angle     : KindTagQ0
  | custom    : Nat → KindTagQ0
  deriving DecidableEq, Repr, Inhabited

/-- Full static unit & physical quantity specification in SIR-Core-Q0. -/
structure UnitSpecQ0 where
  dim  : DimVec7
  kind : KindTagQ0 := .canonical
  deriving DecidableEq, Repr, Inhabited

namespace UnitSpecQ0

def unitless : UnitSpecQ0 := { dim := DimVec7.zero, kind := .canonical }
def meter    : UnitSpecQ0 := { dim := { L := 1 }, kind := .canonical }
def meterSq  : UnitSpecQ0 := { dim := { L := 2 }, kind := .canonical }
def second   : UnitSpecQ0 := { dim := { T := 1 }, kind := .canonical }
def mole     : UnitSpecQ0 := { dim := { N := 1 }, kind := .canonical }
def energy   : UnitSpecQ0 := { dim := { L := 2, M := 1, T := -2 }, kind := .canonical }
def torque   : UnitSpecQ0 := { dim := { L := 2, M := 1, T := -2 }, kind := .torque }
def radian   : UnitSpecQ0 := { dim := DimVec7.zero, kind := .angle }

end UnitSpecQ0

/-- Primitive binary arithmetic operations in SIR-Core-Q0. -/
inductive BinOpQ0 where
  | add : BinOpQ0
  | sub : BinOpQ0
  | mul : BinOpQ0
  | div : BinOpQ0
  deriving DecidableEq, Repr, Inhabited

/-- Static unit synthesis rule for binary operators, preserving both 7D SI dimension
    and physical quantity kind without collapsing Energy and Torque. -/
def synthBinOpUnit (op : BinOpQ0) (u1 u2 : UnitSpecQ0) : Option UnitSpecQ0 :=
  match op with
  | .add | .sub =>
      if u1 = u2 then some u1 else none
  | .mul =>
      if u1 = UnitSpecQ0.unitless then some u2
      else if u2 = UnitSpecQ0.unitless then some u1
      else if u1.kind = .canonical ∧ u2.kind = .canonical then
        some { dim := DimVec7.add u1.dim u2.dim, kind := .canonical }
      else none
  | .div =>
      if u2 = UnitSpecQ0.unitless then some u1
      else if u1 = u2 then some UnitSpecQ0.unitless
      else if u1.kind = .canonical ∧ u2.kind = .canonical then
        some { dim := DimVec7.sub u1.dim u2.dim, kind := .canonical }
      else none

/-- First-order De Bruijn AST for SIR-Core-Q0 expressions. -/
inductive ExprQ0 where
  | bvar     : Nat → ExprQ0
  | ratLit   : Rat → UnitSpecQ0 → ExprQ0
  | unaryNeg : ExprQ0 → ExprQ0
  | binOp    : BinOpQ0 → ExprQ0 → ExprQ0 → ExprQ0
  | letBind  : ExprQ0 → ExprQ0 → ExprQ0
  deriving DecidableEq, Repr, Inhabited

/-- Domain & sign guard predicates over SIR-Core-Q0 expressions. -/
inductive GuardQ0 where
  | nonZero : ExprQ0 → GuardQ0
  | pos     : ExprQ0 → GuardQ0
  | nonNeg  : ExprQ0 → GuardQ0
  deriving DecidableEq, Repr, Inhabited

def guardExpr : GuardQ0 → ExprQ0
  | .nonZero e => e
  | .pos e     => e
  | .nonNeg e  => e

/-- Context equality hypothesis propositions in SIR-Core-Q0. -/
inductive PropQ0 where
  | eqProp : ExprQ0 → ExprQ0 → PropQ0
  deriving DecidableEq, Repr, Inhabited

abbrev VarCtxQ0 := List UnitSpecQ0
abbrev HypCtxQ0 := List PropQ0

/-- Decidable De Bruijn scoping check at binder depth `c`. -/
def wellScoped (c : Nat) : ExprQ0 → Bool
  | .bvar i        => decide (i < c)
  | .ratLit _ _    => true
  | .unaryNeg a    => wellScoped c a
  | .binOp _ a b   => wellScoped c a && wellScoped c b
  | .letBind v b   => wellScoped c v && wellScoped (c + 1) b

/-- Expressions proven well-scoped within `c` enclosing variables. -/
abbrev ScopedExpr (c : Nat) := { e : ExprQ0 // wellScoped c e = true }

/-- Static unit synthesis on `ExprQ0` under variable context `Γ`. -/
def synthUnit (Γ : VarCtxQ0) : ExprQ0 → Option UnitSpecQ0
  | .bvar i => Γ[i]?
  | .ratLit _ u => some u
  | .unaryNeg a => synthUnit Γ a
  | .binOp op a b =>
      match synthUnit Γ a, synthUnit Γ b with
      | some u1, some u2 => synthBinOpUnit op u1 u2
      | _, _ => none
  | .letBind v body =>
      match synthUnit Γ v with
      | some uv => synthUnit (uv :: Γ) body
      | none => none

/-- Well-typed expressions are automatically well-scoped. -/
theorem synthUnit_imp_wellScoped :
    ∀ (e : ExprQ0) {Γ : VarCtxQ0} {u : UnitSpecQ0},
      synthUnit Γ e = some u → wellScoped Γ.length e = true
  | .bvar i, Γ, u, h => by
      simp only [synthUnit] at h
      have hi : i < Γ.length :=
        if hlt : i < Γ.length then hlt
        else False.elim (by
          have hnone : Γ[i]? = none := List.getElem?_eq_none (Nat.le_of_not_lt hlt)
          rw [hnone] at h
          contradiction)
      simp [wellScoped, hi]
  | .ratLit _ _, _, _, _ => rfl
  | .unaryNeg a, _, _, h => by
      simp only [synthUnit] at h
      exact synthUnit_imp_wellScoped a h
  | .binOp _ a b, Γ, _, h => by
      simp only [synthUnit] at h
      cases ha : synthUnit Γ a with
      | none => rw [ha] at h; contradiction
      | some u1 =>
        cases hb : synthUnit Γ b with
        | none => rw [ha, hb] at h; contradiction
        | some u2 =>
          simp [wellScoped, synthUnit_imp_wellScoped a ha, synthUnit_imp_wellScoped b hb]
  | .letBind v body, Γ, _, h => by
      simp only [synthUnit] at h
      cases hv : synthUnit Γ v with
      | none => rw [hv] at h; contradiction
      | some uv =>
        rw [hv] at h
        dsimp only at h
        have hwv := synthUnit_imp_wellScoped v hv
        have hwb := synthUnit_imp_wellScoped body h
        simp [wellScoped, hwv]
        exact hwb

/-- De Bruijn index lifting: shifts indices `≥ cutoff` upward by `k`. -/
def liftExpr (cutoff k : Nat) : ExprQ0 → ExprQ0
  | .bvar i => if i < cutoff then .bvar i else .bvar (i + k)
  | .ratLit q u => .ratLit q u
  | .unaryNeg a => .unaryNeg (liftExpr cutoff k a)
  | .binOp op a b => .binOp op (liftExpr cutoff k a) (liftExpr cutoff k b)
  | .letBind v body => .letBind (liftExpr cutoff k v) (liftExpr (cutoff + 1) k body)

/-- De Bruijn substitution at binder depth `j`: replaces `bvar j` with lifted `s`
    and decrements indices `> j`. -/
def substExpr (j : Nat) (s : ExprQ0) : ExprQ0 → ExprQ0
  | .bvar i =>
      if i < j then .bvar i
      else if i = j then liftExpr 0 j s
      else .bvar (i - 1)
  | .ratLit q u => .ratLit q u
  | .unaryNeg a => .unaryNeg (substExpr j s a)
  | .binOp op a b => .binOp op (substExpr j s a) (substExpr j s b)
  | .letBind v body => .letBind (substExpr j s v) (substExpr (j + 1) s body)

/-- Top-level substitution for `bvar 0` (`letBind` beta-substitution). -/
def subst0 (v body : ExprQ0) : ExprQ0 :=
  substExpr 0 v body

/-- Guard substitution for `bvar 0` (`R1` §1.2 `substGuard0`). -/
def substGuard0 (v : ExprQ0) : GuardQ0 → GuardQ0
  | .nonZero d => .nonZero (subst0 v d)
  | .pos d     => .pos (subst0 v d)
  | .nonNeg d  => .nonNeg (subst0 v d)

theorem guardExpr_substGuard0 (v : ExprQ0) (ω : GuardQ0) :
    guardExpr (substGuard0 v ω) = subst0 v (guardExpr ω) := by
  cases ω <;> rfl

/-! ### Helper List Indexing Lemmas for De Bruijn Weakening & Substitution -/

theorem getElem?_append_middle {α : Type} (Γ₁ Γ_mid Γ₂ : List α) (i : Nat) :
    (if i < Γ₁.length then (Γ₁ ++ Γ_mid ++ Γ₂)[i]?
     else (Γ₁ ++ Γ_mid ++ Γ₂)[i + Γ_mid.length]?) = (Γ₁ ++ Γ₂)[i]? := by
  split
  · rename_i hlt
    have hlt1 : i < (Γ₁ ++ Γ_mid).length := by
      rw [List.length_append]; omega
    rw [List.getElem?_append_left (by rw [List.length_append]; omega)]
    rw [List.getElem?_append_left hlt]
    rw [List.getElem?_append_left hlt]
  · rename_i hge
    have hge' : Γ₁.length ≤ i := Nat.le_of_not_lt hge
    have h1 : (Γ₁ ++ Γ₂)[i]? = Γ₂[i - Γ₁.length]? :=
      List.getElem?_append_right hge'
    have hge_mid : (Γ₁ ++ Γ_mid).length ≤ i + Γ_mid.length := by
      rw [List.length_append]; omega
    have h2 : (Γ₁ ++ Γ_mid ++ Γ₂)[i + Γ_mid.length]? =
        Γ₂[(i + Γ_mid.length) - (Γ₁ ++ Γ_mid).length]? :=
      List.getElem?_append_right hge_mid
    have heq : (i + Γ_mid.length) - (Γ₁ ++ Γ_mid).length = i - Γ₁.length := by
      rw [List.length_append]; omega
    rw [h1, h2, heq]

theorem getElem?_subst_at {α : Type} (Γ₁ : List α) (u : α) (Γ₂ : List α) (i : Nat) :
    (Γ₁ ++ u :: Γ₂)[i]? =
      if i < Γ₁.length then (Γ₁ ++ Γ₂)[i]?
      else if i = Γ₁.length then some u
      else (Γ₁ ++ Γ₂)[i - 1]? := by
  split
  · rename_i hlt
    rw [List.getElem?_append_left hlt, List.getElem?_append_left hlt]
  · rename_i hge
    have hle : Γ₁.length ≤ i := Nat.le_of_not_lt hge
    rw [List.getElem?_append_right hle]
    split
    · rename_i heq
      subst heq
      simp
    · rename_i hne
      have hgt : Γ₁.length < i := Nat.lt_of_le_of_ne hle (Ne.symm hne)
      have hsub_pos : i - Γ₁.length = (i - 1 - Γ₁.length) + 1 := by omega
      rw [hsub_pos]
      simp only [List.getElem?_cons_succ]
      have hle' : Γ₁.length ≤ i - 1 := by omega
      rw [List.getElem?_append_right hle']

/-- Scoping preservation under `liftExpr`. -/
theorem wellScoped_liftExpr :
    ∀ (e : ExprQ0) (cutoff k c : Nat),
      cutoff ≤ c →
      wellScoped c e = true →
      wellScoped (c + k) (liftExpr cutoff k e) = true
  | .bvar i, cutoff, k, c, hle, hw => by
      simp only [wellScoped, decide_eq_true_eq] at hw
      simp only [liftExpr]
      split
      · simp [wellScoped]; omega
      · simp [wellScoped]; omega
  | .ratLit _ _, _, _, _, _, _ => rfl
  | .unaryNeg a, cutoff, k, c, hle, hw =>
      wellScoped_liftExpr a cutoff k c hle hw
  | .binOp op a b, cutoff, k, c, hle, hw => by
      simp only [liftExpr, wellScoped, Bool.and_eq_true] at hw ⊢
      exact ⟨wellScoped_liftExpr a cutoff k c hle hw.1,
             wellScoped_liftExpr b cutoff k c hle hw.2⟩
  | .letBind v body, cutoff, k, c, hle, hw => by
      simp only [liftExpr, wellScoped, Bool.and_eq_true] at hw ⊢
      have h1 := wellScoped_liftExpr v cutoff k c hle hw.1
      have h2 := wellScoped_liftExpr body (cutoff + 1) k (c + 1) (by omega) hw.2
      have heq : c + 1 + k = c + k + 1 := by omega
      rw [heq] at h2
      exact ⟨h1, h2⟩

/-- General unit preservation under De Bruijn weakening (`liftExpr`). -/
theorem synthUnit_liftExpr :
    ∀ (e : ExprQ0) (Γ₁ Γ_mid Γ₂ : VarCtxQ0),
      synthUnit (Γ₁ ++ Γ_mid ++ Γ₂) (liftExpr Γ₁.length Γ_mid.length e) =
        synthUnit (Γ₁ ++ Γ₂) e
  | .bvar i, Γ₁, Γ_mid, Γ₂ => by
      simp only [liftExpr]
      split
      · rename_i hlt
        have h := getElem?_append_middle Γ₁ Γ_mid Γ₂ i
        simp only [if_pos hlt] at h
        simpa [synthUnit] using h
      · rename_i hge
        have h := getElem?_append_middle Γ₁ Γ_mid Γ₂ i
        simp only [if_neg hge] at h
        simpa [synthUnit] using h
  | .ratLit _ _, _, _, _ => rfl
  | .unaryNeg a, Γ₁, Γ_mid, Γ₂ =>
      synthUnit_liftExpr a Γ₁ Γ_mid Γ₂
  | .binOp op a b, Γ₁, Γ_mid, Γ₂ => by
      simp only [liftExpr, synthUnit, synthUnit_liftExpr a Γ₁ Γ_mid Γ₂,
                 synthUnit_liftExpr b Γ₁ Γ_mid Γ₂]
  | .letBind v body, Γ₁, Γ_mid, Γ₂ => by
      simp only [liftExpr, synthUnit, synthUnit_liftExpr v Γ₁ Γ_mid Γ₂]
      cases synthUnit (Γ₁ ++ Γ₂) v with
      | none => rfl
      | some uv =>
        dsimp only
        have hcons : uv :: (Γ₁ ++ Γ_mid ++ Γ₂) = (uv :: Γ₁) ++ Γ_mid ++ Γ₂ := rfl
        have hlen : Γ₁.length + 1 = (uv :: Γ₁).length := rfl
        rw [hcons, hlen]
        exact synthUnit_liftExpr body (uv :: Γ₁) Γ_mid Γ₂

/-- Corollary: single-binder weakening at depth 0. -/
theorem synthUnit_lift0_one (u₀ : UnitSpecQ0) (Γ : VarCtxQ0) (e : ExprQ0) :
    synthUnit (u₀ :: Γ) (liftExpr 0 1 e) = synthUnit Γ e := by
  have h := synthUnit_liftExpr e [] [u₀] Γ
  simpa using h

/-- General unit preservation under De Bruijn substitution (`substExpr`). -/
theorem synthUnit_substExpr :
    ∀ (e : ExprQ0) (Γ₁ Γ₂ : VarCtxQ0) (s : ExprQ0) (u_s : UnitSpecQ0),
      synthUnit Γ₂ s = some u_s →
      synthUnit (Γ₁ ++ Γ₂) (substExpr Γ₁.length s e) =
        synthUnit (Γ₁ ++ u_s :: Γ₂) e
  | .bvar i, Γ₁, Γ₂, s, u_s, hs => by
      have hidx := getElem?_subst_at Γ₁ u_s Γ₂ i
      simp only [substExpr]
      split
      · rename_i hlt
        simp only [if_pos hlt] at hidx
        simpa [synthUnit] using hidx.symm
      · rename_i hge
        simp only [if_neg hge] at hidx
        split
        · rename_i heq
          simp only [if_pos heq] at hidx
          have hlift := synthUnit_liftExpr s [] Γ₁ Γ₂
          simp only [List.length_nil, List.nil_append] at hlift
          have rhs_eq : synthUnit (Γ₁ ++ u_s :: Γ₂) (.bvar i) = some u_s := by
            simpa [synthUnit] using hidx
          rw [rhs_eq]
          exact hlift.trans hs
        · rename_i hne
          simp only [if_neg hne] at hidx
          simpa [synthUnit] using hidx.symm
  | .ratLit _ _, _, _, _, _, _ => rfl
  | .unaryNeg a, Γ₁, Γ₂, s, u_s, hs =>
      synthUnit_substExpr a Γ₁ Γ₂ s u_s hs
  | .binOp op a b, Γ₁, Γ₂, s, u_s, hs => by
      simp only [substExpr, synthUnit,
                 synthUnit_substExpr a Γ₁ Γ₂ s u_s hs,
                 synthUnit_substExpr b Γ₁ Γ₂ s u_s hs]
  | .letBind v body, Γ₁, Γ₂, s, u_s, hs => by
      simp only [substExpr, synthUnit, synthUnit_substExpr v Γ₁ Γ₂ s u_s hs]
      cases synthUnit (Γ₁ ++ u_s :: Γ₂) v with
      | none => rfl
      | some uv =>
        dsimp only
        have hlen : Γ₁.length + 1 = (uv :: Γ₁).length := rfl
        rw [hlen]
        exact synthUnit_substExpr body (uv :: Γ₁) Γ₂ s u_s hs

/-- Target Obligation `LEM-SubstUnit` (`M1-P0 R2/R3`):
    Substituting a well-typed bound expression `v` at `bvar 0` preserves static unit synthesis. -/
theorem lem_substUnit {Γ : VarCtxQ0} {v body : ExprQ0} {u_v : UnitSpecQ0}
    (hv : synthUnit Γ v = some u_v) :
    synthUnit Γ (subst0 v body) = synthUnit (u_v :: Γ) body := by
  exact synthUnit_substExpr body [] Γ v u_v hv

/-- Guard-level corollary of `LEM-SubstUnit`: `substGuard0` preserves unit synthesis. -/
theorem lem_substGuardUnit {Γ : VarCtxQ0} {v : ExprQ0} {u_v : UnitSpecQ0}
    (hv : synthUnit Γ v = some u_v) (ω : GuardQ0) :
    synthUnit Γ (guardExpr (substGuard0 v ω)) = synthUnit (u_v :: Γ) (guardExpr ω) := by
  rw [guardExpr_substGuard0]
  exact lem_substUnit hv

end GrandZero.StageA
