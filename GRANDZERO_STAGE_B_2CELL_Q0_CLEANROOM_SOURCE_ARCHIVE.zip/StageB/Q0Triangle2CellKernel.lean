/-
  GRANDZERO Ω — Stage B (Minimal 3-Context · 1-Triangle 2-Cell Certifier)
  Module B-4: Q0Triangle2CellKernel.lean
  Scope:
    1. Explicit separation of `LogicalCommutation` vs. `NonVacuousBridge` (`F-PHCA-B02`).
    2. Strict 5-way `TriangleAuditOutcomeQ0` (`F-PHCA-B01`, `F-PHCA-B03`):
       `verifiedExactBridge`, `verifiedPathDiscrepancy`, `verifiedEmptyOverlap`,
       `verifiedBridgeDomainViolation`, and `rejectedIllTypedOrUnverified`.
    3. Core Soundness & Mutual-Exclusion Theorems (`thm_stageB_exact_bridge_sound`,
       `thm_stageB_path_discrepancy_sound_and_exclusive`,
       `thm_stageB_empty_overlap_sound_and_exclusive`,
       `thm_stageB_domain_violation_sound_and_exclusive`,
       `thm_stageB_ill_typed_universal_reject`, `thm_stageB_authority_universal_reject`).
    4. Exact 2-Cell Rational Defect Calculus & Formal Polynomial Valuation Order
       (`compute2CellDefect`, `thm_2cell_exact_defect_sound`, `minVarDegPoly`,
       `thm_poly_vanishes_at_var_zero`, `Tribunal Refinement 2.D`).
-/

import StageB.Q0ConeEmptyOverlap

namespace GrandZero.StageB

open GrandZero.StageA

/-! ### Part 1: 3-Context · 1-Triangle Diagram & Semantic Predicates (`F-PHCA-B02`) -/

/-- Minimal 3-Context · 1-Triangle 2-Cell Diagram over common overlap `C123`:
    `C123 --iota1--> C1`, `C1 --f12--> C2 --f23--> C3` vs. `C1 --f13--> C3`,
    comparing local observable `obs3` on `C3`. -/
structure Triangle2CellSpecQ0 where
  C123  : ContextQ0
  C1    : ContextQ0
  C2    : ContextQ0
  C3    : ContextQ0
  iota1 : BridgeMorphismQ0
  f12   : BridgeMorphismQ0
  f23   : BridgeMorphismQ0
  f13   : BridgeMorphismQ0
  obs3  : ExprQ0
  deriving DecidableEq, Repr, Inhabited

/-- Composite path observable `e_123 := ι₁*(f₁₂*(f₂₃*(obs₃)))` over `C123`. -/
def compositeExpr (T : Triangle2CellSpecQ0) : ExprQ0 :=
  substMap T.iota1.coords (substMap T.f12.coords (substMap T.f23.coords T.obs3))

/-- Direct path observable `e_13 := ι₁*(f₁₃*(obs₃))` over `C123`. -/
def directExpr (T : Triangle2CellSpecQ0) : ExprQ0 :=
  substMap T.iota1.coords (substMap T.f13.coords T.obs3)

/-- Vacuously-permissive logical commutation (`∀ ρ ∈ U, StrongEq ρ e_123 e_13`). -/
def LogicalCommutation (C123 : ContextQ0) (e123 e13 : ExprQ0) : Prop :=
  ∀ ρ : List Rat, ValidDomainQ0 ρ C123 → StrongEq ρ e123 e13

/-- Certified non-vacuous gluing (`(∃ ρ₀, ρ₀ ∈ U) ∧ LogicalCommutation`, `F-PHCA-B02`). -/
def NonVacuousBridge (C123 : ContextQ0) (e123 e13 : ExprQ0) : Prop :=
  (∃ ρ₀ : List Rat, ValidDomainQ0 ρ₀ C123) ∧ LogicalCommutation C123 e123 e13

/-! ### Part 2: Static Wiring, Units, Authority, & Stepwise Path Semantics -/

/-- Static diagram wiring & `UnitSpecQ0` (`DimVec7` + `KindTagQ0`) gate. -/
def checkTriangleWiringAndUnits (T : Triangle2CellSpecQ0) : Bool :=
  decide (T.iota1.src = T.C123 ∧ T.iota1.dst = T.C1) &&
  decide (T.f12.src = T.C1 ∧ T.f12.dst = T.C2) &&
  decide (T.f23.src = T.C2 ∧ T.f23.dst = T.C3) &&
  decide (T.f13.src = T.C1 ∧ T.f13.dst = T.C3) &&
  checkBridgeUnitsOnly T.iota1 &&
  checkBridgeUnitsOnly T.f12 &&
  checkBridgeUnitsOnly T.f23 &&
  checkBridgeUnitsOnly T.f13 &&
  (synthUnit T.C3.vars T.obs3).isSome

/-- Static 3D product-lattice authority non-escalation gate across the entire triangle. -/
def checkTriangleAuthorities (T : Triangle2CellSpecQ0) : Bool :=
  checkAuthorityLe T.iota1.dstAuth T.iota1.srcAuth &&
  checkAuthorityLe T.f12.srcAuth T.iota1.dstAuth &&
  checkAuthorityLe T.f12.dstAuth T.f12.srcAuth &&
  checkAuthorityLe T.f23.srcAuth T.f12.dstAuth &&
  checkAuthorityLe T.f23.dstAuth T.f23.srcAuth &&
  checkAuthorityLe T.f13.srcAuth T.iota1.dstAuth &&
  checkAuthorityLe T.f13.dstAuth T.f13.srcAuth

theorem lem_triangle_StaticUnits (T : Triangle2CellSpecQ0)
    (hwu : checkTriangleWiringAndUnits T = true) :
    ∃ u_obs : UnitSpecQ0,
      synthUnit T.C3.vars T.obs3 = some u_obs ∧
      synthUnit T.C123.vars (compositeExpr T) = some u_obs ∧
      synthUnit T.C123.vars (directExpr T) = some u_obs ∧
      wellScoped T.C123.vars.length (compositeExpr T) = true ∧
      wellScoped T.C123.vars.length (directExpr T) = true := by
  unfold checkTriangleWiringAndUnits checkBridgeUnitsOnly at hwu
  simp only [Bool.and_eq_true, decide_eq_true_eq] at hwu
  rcases hwu with ⟨⟨⟨⟨⟨⟨⟨⟨hw_i1, hw_12⟩, hw_23⟩, hw_13⟩, hu_i1⟩, hu_12⟩, hu_23⟩, hu_13⟩, hobs_some⟩
  cases hobs : synthUnit T.C3.vars T.obs3 with
  | none => rw [hobs] at hobs_some; contradiction
  | some u_obs =>
      have hc_i1 : checkCoordsUnits T.C123.vars T.iota1.coords T.C1.vars = true := by
        rw [← hw_i1.1, ← hw_i1.2]; exact hu_i1.2
      have hc_12 : checkCoordsUnits T.C1.vars T.f12.coords T.C2.vars = true := by
        rw [← hw_12.1, ← hw_12.2]; exact hu_12.2
      have hc_23 : checkCoordsUnits T.C2.vars T.f23.coords T.C3.vars = true := by
        rw [← hw_23.1, ← hw_23.2]; exact hu_23.2
      have hc_13 : checkCoordsUnits T.C1.vars T.f13.coords T.C3.vars = true := by
        rw [← hw_13.1, ← hw_13.2]; exact hu_13.2
      have hsc3 : wellScoped T.C3.vars.length T.obs3 = true :=
        synthUnit_imp_wellScoped T.obs3 hobs
      have hu2 : synthUnit T.C2.vars (substMap T.f23.coords T.obs3) = some u_obs := by
        rw [lem_substMap_unit T.obs3 hc_23 hsc3, hobs]
      have hsc2 : wellScoped T.C2.vars.length (substMap T.f23.coords T.obs3) = true :=
        synthUnit_imp_wellScoped _ hu2
      have hu1_c : synthUnit T.C1.vars (substMap T.f12.coords (substMap T.f23.coords T.obs3)) = some u_obs := by
        rw [lem_substMap_unit _ hc_12 hsc2, hu2]
      have hsc1_c : wellScoped T.C1.vars.length (substMap T.f12.coords (substMap T.f23.coords T.obs3)) = true :=
        synthUnit_imp_wellScoped _ hu1_c
      have hu_comp : synthUnit T.C123.vars (compositeExpr T) = some u_obs := by
        unfold compositeExpr
        rw [lem_substMap_unit _ hc_i1 hsc1_c, hu1_c]
      have hu1_d : synthUnit T.C1.vars (substMap T.f13.coords T.obs3) = some u_obs := by
        rw [lem_substMap_unit T.obs3 hc_13 hsc3, hobs]
      have hsc1_d : wellScoped T.C1.vars.length (substMap T.f13.coords T.obs3) = true :=
        synthUnit_imp_wellScoped _ hu1_d
      have hu_dir : synthUnit T.C123.vars (directExpr T) = some u_obs := by
        unfold directExpr
        rw [lem_substMap_unit _ hc_i1 hsc1_d, hu1_d]
      exact ⟨u_obs, rfl, hu_comp, hu_dir,
             synthUnit_imp_wellScoped _ hu_comp,
             synthUnit_imp_wellScoped _ hu_dir⟩

/-- Stepwise semantic path evaluator at `ρ`:
    returns `some (v_123, v_13)` iff all intermediate coordinate evaluations succeed,
    every intermediate state belongs to its destination `ValidDomainQ0`, and `obs3`
    evaluates to `some v_123` and `some v_13` respectively. -/
def checkAllStepsValidAt (ρ : List Rat) (T : Triangle2CellSpecQ0) : Option (Rat × Rat) :=
  match evalCoords ρ T.iota1.coords with
  | none => none
  | some ρ1 =>
      if !checkValidDomainQ0 ρ1 T.C1 then none
      else
        match evalCoords ρ1 T.f12.coords, evalCoords ρ1 T.f13.coords with
        | some ρ2, some ρ3d =>
            if !(checkValidDomainQ0 ρ2 T.C2 && checkValidDomainQ0 ρ3d T.C3) then none
            else
              match evalCoords ρ2 T.f23.coords with
              | none => none
              | some ρ3c =>
                  if !checkValidDomainQ0 ρ3c T.C3 then none
                  else
                    match denoteExpr ρ3c T.obs3, denoteExpr ρ3d T.obs3 with
                    | some vc, some vd => some (vc, vd)
                    | _, _             => none
        | _, _ => none

theorem lem_checkAllStepsValidAt_denote (T : Triangle2CellSpecQ0) (ρ : List Rat) (vc vd : Rat)
    (hwu : checkTriangleWiringAndUnits T = true)
    (hsteps : checkAllStepsValidAt ρ T = some (vc, vd)) :
    denoteExpr ρ (compositeExpr T) = some vc ∧ denoteExpr ρ (directExpr T) = some vd := by
  unfold checkTriangleWiringAndUnits checkBridgeUnitsOnly at hwu
  simp only [Bool.and_eq_true, decide_eq_true_eq] at hwu
  rcases hwu with ⟨⟨⟨⟨⟨⟨⟨⟨hw_i1, hw_12⟩, hw_23⟩, hw_13⟩, hu_i1⟩, hu_12⟩, hu_23⟩, hu_13⟩, hobs_some⟩
  cases hobs : synthUnit T.C3.vars T.obs3 with
  | none => rw [hobs] at hobs_some; contradiction
  | some u_obs =>
      have hc_12 : checkCoordsUnits T.C1.vars T.f12.coords T.C2.vars = true := by
        rw [← hw_12.1, ← hw_12.2]; exact hu_12.2
      have hc_23 : checkCoordsUnits T.C2.vars T.f23.coords T.C3.vars = true := by
        rw [← hw_23.1, ← hw_23.2]; exact hu_23.2
      have hc_13 : checkCoordsUnits T.C1.vars T.f13.coords T.C3.vars = true := by
        rw [← hw_13.1, ← hw_13.2]; exact hu_13.2
      have hlen_i1 : T.iota1.coords.length = T.C1.vars.length := by
        have h : checkCoordsUnits T.C123.vars T.iota1.coords T.C1.vars = true := by
          rw [← hw_i1.1, ← hw_i1.2]; exact hu_i1.2
        exact checkCoordsUnits_length h
      have hlen_12 : T.f12.coords.length = T.C2.vars.length := checkCoordsUnits_length hc_12
      have hlen_23 : T.f23.coords.length = T.C3.vars.length := checkCoordsUnits_length hc_23
      have hlen_13 : T.f13.coords.length = T.C3.vars.length := checkCoordsUnits_length hc_13
      have hsc3 : wellScoped T.C3.vars.length T.obs3 = true := synthUnit_imp_wellScoped T.obs3 hobs
      have hsc2 : wellScoped T.C2.vars.length (substMap T.f23.coords T.obs3) = true :=
        lem_substMap_wellScoped T.obs3 (checkCoordsUnits_wellScoped hc_23) (by rw [hlen_23]; exact hsc3)
      have hsc1_c : wellScoped T.C1.vars.length (substMap T.f12.coords (substMap T.f23.coords T.obs3)) = true :=
        lem_substMap_wellScoped _ (checkCoordsUnits_wellScoped hc_12) (by rw [hlen_12]; exact hsc2)
      have hsc1_d : wellScoped T.C1.vars.length (substMap T.f13.coords T.obs3) = true :=
        lem_substMap_wellScoped T.obs3 (checkCoordsUnits_wellScoped hc_13) (by rw [hlen_13]; exact hsc3)
      unfold checkAllStepsValidAt at hsteps
      cases hev1 : evalCoords ρ T.iota1.coords with
      | none => rw [hev1] at hsteps; contradiction
      | some ρ1 =>
          rw [hev1] at hsteps; dsimp only at hsteps
          by_cases hv1 : !checkValidDomainQ0 ρ1 T.C1
          · simp [hv1] at hsteps
          · simp only [hv1, Bool.false_eq_true, ↓reduceIte] at hsteps
            cases hev2 : evalCoords ρ1 T.f12.coords with
            | none => rw [hev2] at hsteps; contradiction
            | some ρ2 =>
              cases hev3d : evalCoords ρ1 T.f13.coords with
              | none => rw [hev2, hev3d] at hsteps; contradiction
              | some ρ3d =>
                  rw [hev2, hev3d] at hsteps; dsimp only at hsteps
                  by_cases hv2 : !(checkValidDomainQ0 ρ2 T.C2 && checkValidDomainQ0 ρ3d T.C3)
                  · simp [hv2] at hsteps
                  · simp only [hv2, Bool.false_eq_true, ↓reduceIte] at hsteps
                    cases hev3c : evalCoords ρ2 T.f23.coords with
                    | none => rw [hev3c] at hsteps; contradiction
                    | some ρ3c =>
                        rw [hev3c] at hsteps; dsimp only at hsteps
                        by_cases hv3c : !checkValidDomainQ0 ρ3c T.C3
                        · simp [hv3c] at hsteps
                        · simp only [hv3c, Bool.false_eq_true, ↓reduceIte] at hsteps
                          cases hdc : denoteExpr ρ3c T.obs3 with
                          | none => rw [hdc] at hsteps; contradiction
                          | some vc' =>
                            cases hdd : denoteExpr ρ3d T.obs3 with
                            | none => rw [hdc, hdd] at hsteps; contradiction
                            | some vd' =>
                                rw [hdc, hdd] at hsteps
                                simp only [Option.some.injEq, Prod.mk.injEq] at hsteps
                                rcases hsteps with ⟨rfl, rfl⟩
                                refine ⟨?_, ?_⟩
                                · unfold compositeExpr
                                  rw [lem_substMap_denote _ hev1 (by rw [hlen_i1]; exact hsc1_c)]
                                  rw [lem_substMap_denote _ hev2 (by rw [hlen_12]; exact hsc2)]
                                  rw [lem_substMap_denote _ hev3c (by rw [hlen_23]; exact hsc3)]
                                  exact hdc
                                · unfold directExpr
                                  rw [lem_substMap_denote _ hev1 (by rw [hlen_i1]; exact hsc1_d)]
                                  rw [lem_substMap_denote _ hev3d (by rw [hlen_13]; exact hsc3)]
                                  exact hdd

/-! ### Part 3: Strict 5-Way Outcome Type & Witness Auditor (`F-PHCA-B01`, `F-PHCA-B03`) -/

/-- Fine-grained static/witness rejection code for `rejectedIllTypedOrUnverified`. -/
inductive StageBRejectCodeQ0 where
  | illTypedBridge                       : StageBRejectCodeQ0
  | authorityEscalation                  : StageBRejectCodeQ0
  | invalidWitnessOrConservativeUnverified : StageBRejectCodeQ0
  deriving DecidableEq, Repr, Inhabited

/-- Strict 5-way Stage B triangle audit outcome (`F-PHCA-B01`). -/
inductive TriangleAuditOutcomeQ0 where
  | verifiedExactBridge           : TriangleAuditOutcomeQ0
  | verifiedPathDiscrepancy       : TriangleAuditOutcomeQ0
  | verifiedEmptyOverlap          : TriangleAuditOutcomeQ0
  | verifiedBridgeDomainViolation : TriangleAuditOutcomeQ0
  | rejectedIllTypedOrUnverified  : StageBRejectCodeQ0 → TriangleAuditOutcomeQ0
  deriving DecidableEq, Repr, Inhabited

/-- Whitebox witness certificates submitted to `auditTriangle2Cell`. -/
inductive Triangle2CellWitnessQ0 where
  | exactBridgeCert
      (ρ_inhabit     : List Rat)
      (cert_iota1    : BridgeCertQ0)
      (cert_f12      : BridgeCertQ0)
      (cert_f23      : BridgeCertQ0)
      (cert_f13      : BridgeCertQ0)
      (pole123Proofs : List BridgeGuardProofQ0)
      (pole13Proofs  : List BridgeGuardProofQ0)
  | pathDiscrepancyCert
      (ρ_star : List Rat)
  | emptyOverlapCert
      (emptyCert : EmptyOverlapCertQ0)
  | bridgeDomainViolationCert
      (ρ_viol : List Rat)
  deriving DecidableEq, Repr, Inhabited

/-- Trusted 2-Cell Triangle Whitebox Certifier (`auditTriangle2Cell`, `F-PHCA-B01~B03`). -/
def auditTriangle2Cell
    (T : Triangle2CellSpecQ0) (w : Triangle2CellWitnessQ0) : TriangleAuditOutcomeQ0 :=
  if !checkTriangleWiringAndUnits T then
    .rejectedIllTypedOrUnverified .illTypedBridge
  else if !checkTriangleAuthorities T then
    .rejectedIllTypedOrUnverified .authorityEscalation
  else
    match w with
    | .exactBridgeCert ρ_inhabit c_i1 c_12 c_23 c_13 p123 p13 =>
        if !(checkValidDomainQ0 ρ_inhabit T.C123 &&
             checkBridgeCert T.iota1 c_i1 &&
             checkBridgeCert T.f12 c_12 &&
             checkBridgeCert T.f23 c_23 &&
             checkBridgeCert T.f13 c_13) then
          .rejectedIllTypedOrUnverified .invalidWitnessOrConservativeUnverified
        else if hsc : wellScoped T.C123.vars.length (compositeExpr T) = true ∧
                      wellScoped T.C123.vars.length (directExpr T) = true then
          let rt123 := lowerExprTop T.C123.vars.length ⟨compositeExpr T, hsc.1⟩
          let rt13  := lowerExprTop T.C123.vars.length ⟨directExpr T, hsc.2⟩
          match reflectTapeRoot T.C123.vars rt123, reflectTapeRoot T.C123.vars rt13 with
          | some r123, some r13 =>
              if r123.unit == r13.unit &&
                 checkBridgeGuardList T.C123.vars T.C123.hyps T.C123.guards p123 r123.guards &&
                 checkBridgeGuardList T.C123.vars T.C123.hyps T.C123.guards p13 r13.guards &&
                 (canonPoly (polySub (polyMul r123.num r13.den) (polyMul r13.num r123.den)) == PolyQ0.zero) then
                .verifiedExactBridge
              else
                .rejectedIllTypedOrUnverified .invalidWitnessOrConservativeUnverified
          | _, _ => .rejectedIllTypedOrUnverified .invalidWitnessOrConservativeUnverified
        else
          .rejectedIllTypedOrUnverified .invalidWitnessOrConservativeUnverified
    | .pathDiscrepancyCert ρ_star =>
        if !checkValidDomainQ0 ρ_star T.C123 then
          .rejectedIllTypedOrUnverified .invalidWitnessOrConservativeUnverified
        else
          match checkAllStepsValidAt ρ_star T with
          | some (vc, vd) =>
              if vc != vd then .verifiedPathDiscrepancy
              else .rejectedIllTypedOrUnverified .invalidWitnessOrConservativeUnverified
          | none => .rejectedIllTypedOrUnverified .invalidWitnessOrConservativeUnverified
    | .emptyOverlapCert emptyCert =>
        if checkEmptyOverlapCert T.C123 emptyCert then .verifiedEmptyOverlap
        else .rejectedIllTypedOrUnverified .invalidWitnessOrConservativeUnverified
    | .bridgeDomainViolationCert ρ_viol =>
        if checkValidDomainQ0 ρ_viol T.C123 && (checkAllStepsValidAt ρ_viol T).isNone then
          .verifiedBridgeDomainViolation
        else
          .rejectedIllTypedOrUnverified .invalidWitnessOrConservativeUnverified

/-! ### Part 4: Core Stage B Soundness & Mutual-Exclusion Theorems -/

/-- Universal Rejection Theorem for Ill-Typed Bridges (`TB-04` class):
    Any unit/`KindTagQ0` or wiring mismatch forces `.rejectedIllTypedOrUnverified .illTypedBridge`
    across ALL candidate witnesses `w`. -/
theorem thm_stageB_ill_typed_universal_reject
    (T : Triangle2CellSpecQ0)
    (hbad : checkTriangleWiringAndUnits T = false) :
    ∀ w : Triangle2CellWitnessQ0,
      auditTriangle2Cell T w = .rejectedIllTypedOrUnverified .illTypedBridge := by
  intro w
  simp [auditTriangle2Cell, hbad]

/-- Universal Rejection Theorem for Authority Escalation (`TB-06` class):
    Well-typed triangles violating 3D product-lattice authority non-escalation force
    `.rejectedIllTypedOrUnverified .authorityEscalation` across ALL candidate witnesses `w`. -/
theorem thm_stageB_authority_universal_reject
    (T : Triangle2CellSpecQ0)
    (hwu : checkTriangleWiringAndUnits T = true)
    (hbad : checkTriangleAuthorities T = false) :
    ∀ w : Triangle2CellWitnessQ0,
      auditTriangle2Cell T w = .rejectedIllTypedOrUnverified .authorityEscalation := by
  intro w
  simp [auditTriangle2Cell, hwu, hbad]

/-- Target Theorem `THM-STAGEB-01` (`thm_stageB_exact_bridge_sound`):
    `auditTriangle2Cell T w = .verifiedExactBridge` guarantees:
      1. Full 3D authority non-escalation along both composite and direct paths,
      2. Static unit & `KindTagQ0` preservation for `compositeExpr` and `directExpr`,
      3. `NonVacuousBridge` (`Real_ℚ(C123) ≠ ∅` + `∀ ρ ∈ Real_ℚ(C123), StrongEq ρ e_123 e_13`),
      4. Total intermediate & endpoint validity: `∀ ρ ∈ Real_ℚ(C123), ∃ v, checkAllStepsValidAt ρ T = some (v, v)`. -/
theorem thm_stageB_exact_bridge_sound
    (T : Triangle2CellSpecQ0) (w : Triangle2CellWitnessQ0)
    (hok : auditTriangle2Cell T w = .verifiedExactBridge) :
    AuthorityLe T.f23.dstAuth T.iota1.srcAuth ∧
    AuthorityLe T.f13.dstAuth T.iota1.srcAuth ∧
    (∃ u_obs : UnitSpecQ0,
      synthUnit T.C123.vars (compositeExpr T) = some u_obs ∧
      synthUnit T.C123.vars (directExpr T) = some u_obs) ∧
    NonVacuousBridge T.C123 (compositeExpr T) (directExpr T) ∧
    (∀ ρ : List Rat, ValidDomainQ0 ρ T.C123 →
      ∃ v : Rat, checkAllStepsValidAt ρ T = some (v, v)) := by
  unfold auditTriangle2Cell at hok
  cases hwu : checkTriangleWiringAndUnits T with
  | false => simp [hwu] at hok
  | true =>
    simp only [hwu, Bool.not_true, Bool.false_eq_true, ↓reduceIte] at hok
    cases hauth : checkTriangleAuthorities T with
    | false => simp [hauth] at hok
    | true =>
      simp only [hauth, Bool.not_true, Bool.false_eq_true, ↓reduceIte] at hok
      unfold checkTriangleAuthorities at hauth
      simp only [Bool.and_eq_true, lem_checkAuthorityLe_iff] at hauth
      rcases hauth with ⟨⟨⟨⟨⟨⟨ha_i1, ha_i1_12⟩, ha_12⟩, ha_12_23⟩, ha_23⟩, ha_i1_13⟩, ha_13⟩
      have hauth_comp : AuthorityLe T.f23.dstAuth T.iota1.srcAuth :=
        AuthorityLe.trans ha_23 (AuthorityLe.trans ha_12_23 (AuthorityLe.trans ha_12 (AuthorityLe.trans ha_i1_12 ha_i1)))
      have hauth_dir : AuthorityLe T.f13.dstAuth T.iota1.srcAuth :=
        AuthorityLe.trans ha_13 (AuthorityLe.trans ha_i1_13 ha_i1)
      rcases lem_triangle_StaticUnits T hwu with ⟨u_obs, hobs3, hu_comp, hu_dir, _, _⟩
      cases w with
      | pathDiscrepancyCert ρ_star =>
          dsimp only at hok
          by_cases hv : !checkValidDomainQ0 ρ_star T.C123
          · simp [hv] at hok
          · simp only [hv, Bool.false_eq_true, ↓reduceIte] at hok
            cases hst : checkAllStepsValidAt ρ_star T with
            | none => rw [hst] at hok; contradiction
            | some pair =>
                rcases pair with ⟨vc, vd⟩
                rw [hst] at hok
                dsimp only at hok
                by_cases hne : vc != vd <;> simp [hne] at hok
      | emptyOverlapCert emptyCert =>
          cases hce : checkEmptyOverlapCert T.C123 emptyCert <;> simp [hce] at hok
      | bridgeDomainViolationCert ρ_viol =>
          by_cases hv : checkValidDomainQ0 ρ_viol T.C123 && (checkAllStepsValidAt ρ_viol T).isNone <;>
            simp [hv] at hok
      | exactBridgeCert ρ_inhabit c_i1 c_12 c_23 c_13 p123 p13 =>
          dsimp only at hok
          by_cases hpre : !(checkValidDomainQ0 ρ_inhabit T.C123 &&
                            checkBridgeCert T.iota1 c_i1 &&
                            checkBridgeCert T.f12 c_12 &&
                            checkBridgeCert T.f23 c_23 &&
                            checkBridgeCert T.f13 c_13)
          · simp [hpre] at hok
          · simp only [hpre, Bool.false_eq_true, ↓reduceIte] at hok
            have hpre_ok :
                checkValidDomainQ0 ρ_inhabit T.C123 = true ∧
                checkBridgeCert T.iota1 c_i1 = true ∧
                checkBridgeCert T.f12 c_12 = true ∧
                checkBridgeCert T.f23 c_23 = true ∧
                checkBridgeCert T.f13 c_13 = true := by
              cases b0 : checkValidDomainQ0 ρ_inhabit T.C123 <;>
              cases b1 : checkBridgeCert T.iota1 c_i1 <;>
              cases b2 : checkBridgeCert T.f12 c_12 <;>
              cases b3 : checkBridgeCert T.f23 c_23 <;>
              cases b4 : checkBridgeCert T.f13 c_13 <;>
              simp [b0, b1, b2, b3, b4] at hpre ⊢
            by_cases hsc : wellScoped T.C123.vars.length (compositeExpr T) = true ∧
                           wellScoped T.C123.vars.length (directExpr T) = true
            · rw [dif_pos hsc] at hok
              let rt123 := lowerExprTop T.C123.vars.length ⟨compositeExpr T, hsc.1⟩
              let rt13  := lowerExprTop T.C123.vars.length ⟨directExpr T, hsc.2⟩
              cases hr123 : reflectTapeRoot T.C123.vars rt123 with
              | none =>
                  have hr123' : reflectTapeRoot T.C123.vars (lowerExprTop T.C123.vars.length ⟨compositeExpr T, hsc.1⟩) = none := hr123
                  rw [hr123'] at hok; contradiction
              | some r123 =>
                cases hr13 : reflectTapeRoot T.C123.vars rt13 with
                | none =>
                    have hr123' : reflectTapeRoot T.C123.vars (lowerExprTop T.C123.vars.length ⟨compositeExpr T, hsc.1⟩) = some r123 := hr123
                    have hr13'  : reflectTapeRoot T.C123.vars (lowerExprTop T.C123.vars.length ⟨directExpr T, hsc.2⟩) = none := hr13
                    rw [hr123', hr13'] at hok; contradiction
                | some r13 =>
                    have hr123' : reflectTapeRoot T.C123.vars (lowerExprTop T.C123.vars.length ⟨compositeExpr T, hsc.1⟩) = some r123 := hr123
                    have hr13'  : reflectTapeRoot T.C123.vars (lowerExprTop T.C123.vars.length ⟨directExpr T, hsc.2⟩) = some r13 := hr13
                    rw [hr123', hr13'] at hok
                    dsimp only at hok
                    by_cases hfin : r123.unit == r13.unit &&
                        checkBridgeGuardList T.C123.vars T.C123.hyps T.C123.guards p123 r123.guards &&
                        checkBridgeGuardList T.C123.vars T.C123.hyps T.C123.guards p13 r13.guards &&
                        (canonPoly (polySub (polyMul r123.num r13.den) (polyMul r13.num r123.den)) == PolyQ0.zero)
                    · simp only [Bool.and_eq_true, beq_iff_eq] at hfin
                      rcases hfin with ⟨⟨⟨_, hp123_ok⟩, hp13_ok⟩, hpoly0⟩
                      have hinhabit : ValidDomainQ0 ρ_inhabit T.C123 :=
                        (lem_checkValidDomain_iff ρ_inhabit T.C123).mp hpre_ok.1
                      -- Extract wiring equalities from `hwu`
                      have hwiring :
                          (T.iota1.src = T.C123 ∧ T.iota1.dst = T.C1) ∧
                          (T.f12.src = T.C1 ∧ T.f12.dst = T.C2) ∧
                          (T.f23.src = T.C2 ∧ T.f23.dst = T.C3) ∧
                          (T.f13.src = T.C1 ∧ T.f13.dst = T.C3) := by
                        unfold checkTriangleWiringAndUnits at hwu
                        simp only [Bool.and_eq_true, decide_eq_true_eq] at hwu
                        exact ⟨hwu.1.1.1.1.1.1.1.1, hwu.1.1.1.1.1.1.1.2, hwu.1.1.1.1.1.1.2, hwu.1.1.1.1.1.2⟩
                      have hcomm : LogicalCommutation T.C123 (compositeExpr T) (directExpr T) := by
                        intro ρ hvalid
                        rcases hvalid with ⟨henv, hhyps, hguards⟩
                        have hg123 := thm_bridge_guard_list_sound
                          T.C123.vars T.C123.hyps T.C123.guards ρ henv hhyps hguards p123 r123.guards hp123_ok
                        have hg13 := thm_bridge_guard_list_sound
                          T.C123.vars T.C123.hyps T.C123.guards ρ henv hhyps hguards p13 r13.guards hp13_ok
                        rcases thm_tape_gpr_value_sound T.C123.vars ρ henv rt123.tape rt123.root r123 hr123 hg123 with
                          ⟨hden123_nz, hev_t123⟩
                        rcases thm_tape_gpr_value_sound T.C123.vars ρ henv rt13.tape rt13.root r13 hr13 hg13 with
                          ⟨hden13_nz, hev_t13⟩
                        have hcomm123 := (po_tape_equiv ⟨compositeExpr T, hsc.1⟩).1 ρ henv
                        have hcomm13  := (po_tape_equiv ⟨directExpr T, hsc.2⟩).1 ρ henv
                        unfold evalTapeRoot at hcomm123 hcomm13
                        have hd123 : denoteExpr ρ (compositeExpr T) = some (evalPoly ρ r123.num / evalPoly ρ r123.den) := by
                          rw [← hcomm123]; exact hev_t123
                        have hd13 : denoteExpr ρ (directExpr T) = some (evalPoly ρ r13.num / evalPoly ρ r13.den) := by
                          rw [← hcomm13]; exact hev_t13
                        have hcross := canonPoly_eq_zero_sound hpoly0 ρ
                        rw [evalPoly_sub, evalPoly_mul, evalPoly_mul] at hcross
                        have hfeq := rat_eq_of_cross_sub_zero
                          (evalPoly ρ r123.num) (evalPoly ρ r123.den)
                          (evalPoly ρ r13.num) (evalPoly ρ r13.den)
                          hden123_nz hden13_nz hcross
                        exact ⟨evalPoly ρ r123.num / evalPoly ρ r123.den, hd123, by rw [← hfeq] at hd13; exact hd13⟩
                      have hsteps_all : ∀ ρ : List Rat, ValidDomainQ0 ρ T.C123 →
                          ∃ v : Rat, checkAllStepsValidAt ρ T = some (v, v) := by
                        intro ρ hvalid
                        have hstrong := hcomm ρ hvalid
                        rcases hstrong with ⟨v, hd_comp, hd_dir⟩
                        have hvalid_i1 : ValidDomainQ0 ρ T.iota1.src := by rw [hwiring.1.1]; exact hvalid
                        rcases (thm_transport_maps_valid_domain T.iota1 c_i1 hpre_ok.2.1).2 ρ hvalid_i1 with
                          ⟨ρ1, hev1, hv1_dst⟩
                        have hv1 : ValidDomainQ0 ρ1 T.C1 := by rw [← hwiring.1.2]; exact hv1_dst
                        have hv1_12 : ValidDomainQ0 ρ1 T.f12.src := by rw [hwiring.2.1.1]; exact hv1
                        rcases (thm_transport_maps_valid_domain T.f12 c_12 hpre_ok.2.2.1).2 ρ1 hv1_12 with
                          ⟨ρ2, hev2, hv2_dst⟩
                        have hv2 : ValidDomainQ0 ρ2 T.C2 := by rw [← hwiring.2.1.2]; exact hv2_dst
                        have hv2_23 : ValidDomainQ0 ρ2 T.f23.src := by rw [hwiring.2.2.1.1]; exact hv2
                        rcases (thm_transport_maps_valid_domain T.f23 c_23 hpre_ok.2.2.2.1).2 ρ2 hv2_23 with
                          ⟨ρ3c, hev3c, hv3c_dst⟩
                        have hv3c : ValidDomainQ0 ρ3c T.C3 := by rw [← hwiring.2.2.1.2]; exact hv3c_dst
                        have hv1_13 : ValidDomainQ0 ρ1 T.f13.src := by rw [hwiring.2.2.2.1]; exact hv1
                        rcases (thm_transport_maps_valid_domain T.f13 c_13 hpre_ok.2.2.2.2).2 ρ1 hv1_13 with
                          ⟨ρ3d, hev3d, hv3d_dst⟩
                        have hv3d : ValidDomainQ0 ρ3d T.C3 := by rw [← hwiring.2.2.2.2]; exact hv3d_dst
                        -- Show `denoteExpr ρ3c T.obs3 = some v` and `denoteExpr ρ3d T.obs3 = some v`
                        have hb1 : checkValidDomainQ0 ρ1 T.C1 = true := (lem_checkValidDomain_iff ρ1 T.C1).mpr hv1
                        have hb2 : checkValidDomainQ0 ρ2 T.C2 = true := (lem_checkValidDomain_iff ρ2 T.C2).mpr hv2
                        have hb3c : checkValidDomainQ0 ρ3c T.C3 = true := (lem_checkValidDomain_iff ρ3c T.C3).mpr hv3c
                        have hb3d : checkValidDomainQ0 ρ3d T.C3 = true := (lem_checkValidDomain_iff ρ3d T.C3).mpr hv3d
                        -- Evaluate `obs3` via scoping
                        have hsc3 : wellScoped T.C3.vars.length T.obs3 = true := synthUnit_imp_wellScoped T.obs3 hobs3
                        have hwu_copy := hwu
                        unfold checkTriangleWiringAndUnits checkBridgeUnitsOnly at hwu_copy
                        simp only [Bool.and_eq_true, decide_eq_true_eq] at hwu_copy
                        rcases hwu_copy with ⟨⟨⟨⟨⟨⟨⟨⟨_, _⟩, _⟩, _⟩, hu_i1⟩, hu_12⟩, hu_23⟩, hu_13⟩, _⟩
                        have hc_i1 : checkCoordsUnits T.C123.vars T.iota1.coords T.C1.vars = true := by
                          rw [← hwiring.1.1, ← hwiring.1.2]; exact hu_i1.2
                        have hc_12 : checkCoordsUnits T.C1.vars T.f12.coords T.C2.vars = true := by
                          rw [← hwiring.2.1.1, ← hwiring.2.1.2]; exact hu_12.2
                        have hc_23 : checkCoordsUnits T.C2.vars T.f23.coords T.C3.vars = true := by
                          rw [← hwiring.2.2.1.1, ← hwiring.2.2.1.2]; exact hu_23.2
                        have hc_13 : checkCoordsUnits T.C1.vars T.f13.coords T.C3.vars = true := by
                          rw [← hwiring.2.2.2.1, ← hwiring.2.2.2.2]; exact hu_13.2
                        have hsc2 : wellScoped T.C2.vars.length (substMap T.f23.coords T.obs3) = true :=
                          lem_substMap_wellScoped T.obs3 (checkCoordsUnits_wellScoped hc_23)
                            (by rw [checkCoordsUnits_length hc_23]; exact hsc3)
                        have hsc1_c : wellScoped T.C1.vars.length (substMap T.f12.coords (substMap T.f23.coords T.obs3)) = true :=
                          lem_substMap_wellScoped _ (checkCoordsUnits_wellScoped hc_12)
                            (by rw [checkCoordsUnits_length hc_12]; exact hsc2)
                        have hsc1_d : wellScoped T.C1.vars.length (substMap T.f13.coords T.obs3) = true :=
                          lem_substMap_wellScoped T.obs3 (checkCoordsUnits_wellScoped hc_13)
                            (by rw [checkCoordsUnits_length hc_13]; exact hsc3)
                        have hdc_eq : denoteExpr ρ (compositeExpr T) = denoteExpr ρ3c T.obs3 := by
                          unfold compositeExpr
                          rw [lem_substMap_denote _ hev1 (by rw [checkCoordsUnits_length hc_i1]; exact hsc1_c)]
                          rw [lem_substMap_denote _ hev2 (by rw [checkCoordsUnits_length hc_12]; exact hsc2)]
                          rw [lem_substMap_denote _ hev3c (by rw [checkCoordsUnits_length hc_23]; exact hsc3)]
                        have hdd_eq : denoteExpr ρ (directExpr T) = denoteExpr ρ3d T.obs3 := by
                          unfold directExpr
                          rw [lem_substMap_denote _ hev1 (by rw [checkCoordsUnits_length hc_i1]; exact hsc1_d)]
                          rw [lem_substMap_denote _ hev3d (by rw [checkCoordsUnits_length hc_13]; exact hsc3)]
                        rw [hdc_eq] at hd_comp
                        rw [hdd_eq] at hd_dir
                        refine ⟨v, ?_⟩
                        simp [checkAllStepsValidAt, hev1, hb1, hev2, hev3d, hb2, hb3d, hev3c, hb3c, hd_comp, hd_dir]
                      exact ⟨hauth_comp, hauth_dir, ⟨u_obs, hu_comp, hu_dir⟩,
                             ⟨⟨ρ_inhabit, hinhabit⟩, hcomm⟩, hsteps_all⟩
                    · simp [hfin] at hok
            · rw [dif_neg hsc] at hok; contradiction

theorem lem_exactBridgeCert_outcome_dichotomy
    (T : Triangle2CellSpecQ0)
    (ρ_inhabit : List Rat) (c_i1 c_12 c_23 c_13 : BridgeCertQ0)
    (p123 p13 : List BridgeGuardProofQ0) :
    let out := auditTriangle2Cell T (.exactBridgeCert ρ_inhabit c_i1 c_12 c_23 c_13 p123 p13)
    out = .verifiedExactBridge ∨ ∃ r, out = .rejectedIllTypedOrUnverified r := by
  dsimp only
  unfold auditTriangle2Cell
  by_cases hwu : !checkTriangleWiringAndUnits T
  · exact Or.inr ⟨.illTypedBridge, by simp [hwu]⟩
  · simp only [hwu, Bool.false_eq_true, ↓reduceIte]
    by_cases ha : !checkTriangleAuthorities T
    · exact Or.inr ⟨.authorityEscalation, by simp [ha]⟩
    · simp only [ha, Bool.false_eq_true, ↓reduceIte]
      by_cases hpre : !(checkValidDomainQ0 ρ_inhabit T.C123 &&
                        checkBridgeCert T.iota1 c_i1 &&
                        checkBridgeCert T.f12 c_12 &&
                        checkBridgeCert T.f23 c_23 &&
                        checkBridgeCert T.f13 c_13)
      · exact Or.inr ⟨.invalidWitnessOrConservativeUnverified, by simp [hpre]⟩
      · simp only [hpre, Bool.false_eq_true, ↓reduceIte]
        by_cases hsc : wellScoped T.C123.vars.length (compositeExpr T) = true ∧
                       wellScoped T.C123.vars.length (directExpr T) = true
        · rw [dif_pos hsc]
          cases reflectTapeRoot T.C123.vars (lowerExprTop T.C123.vars.length ⟨compositeExpr T, hsc.1⟩) with
          | none => exact Or.inr ⟨.invalidWitnessOrConservativeUnverified, rfl⟩
          | some r123 =>
            cases reflectTapeRoot T.C123.vars (lowerExprTop T.C123.vars.length ⟨directExpr T, hsc.2⟩) with
            | none => exact Or.inr ⟨.invalidWitnessOrConservativeUnverified, rfl⟩
            | some r13 =>
              dsimp only
              by_cases hfin : r123.unit == r13.unit &&
                  checkBridgeGuardList T.C123.vars T.C123.hyps T.C123.guards p123 r123.guards &&
                  checkBridgeGuardList T.C123.vars T.C123.hyps T.C123.guards p13 r13.guards &&
                  (canonPoly (polySub (polyMul r123.num r13.den) (polyMul r13.num r123.den)) == PolyQ0.zero)
              · exact Or.inl (by simp [hfin])
              · exact Or.inr ⟨.invalidWitnessOrConservativeUnverified, by simp [hfin]⟩
        · rw [dif_neg hsc]
          exact Or.inr ⟨.invalidWitnessOrConservativeUnverified, rfl⟩

/-- Target Theorem `THM-STAGEB-02` (`thm_stageB_path_discrepancy_sound_and_exclusive`):
    `auditTriangle2Cell T w = .verifiedPathDiscrepancy` proves a concrete valid point `ρ★ ∈ U`
    where both paths step validly through all intermediate contexts yet evaluate to distinct
    rational values `vc ≠ vd` (`¬ StrongEq`), AND excludes `.verifiedExactBridge` for ALL witnesses! -/
theorem thm_stageB_path_discrepancy_sound_and_exclusive
    (T : Triangle2CellSpecQ0) (w : Triangle2CellWitnessQ0)
    (hdisc : auditTriangle2Cell T w = .verifiedPathDiscrepancy) :
    (∃ ρ_star vc vd,
      ValidDomainQ0 ρ_star T.C123 ∧
      checkAllStepsValidAt ρ_star T = some (vc, vd) ∧
      denoteExpr ρ_star (compositeExpr T) = some vc ∧
      denoteExpr ρ_star (directExpr T) = some vd ∧
      vc ≠ vd ∧
      ¬ StrongEq ρ_star (compositeExpr T) (directExpr T)) ∧
    (∀ w_any : Triangle2CellWitnessQ0, auditTriangle2Cell T w_any ≠ .verifiedExactBridge) := by
  have h : ∃ ρ_star vc vd,
      ValidDomainQ0 ρ_star T.C123 ∧
      checkAllStepsValidAt ρ_star T = some (vc, vd) ∧
      denoteExpr ρ_star (compositeExpr T) = some vc ∧
      denoteExpr ρ_star (directExpr T) = some vd ∧
      vc ≠ vd := by
    cases w with
    | exactBridgeCert ρ_i c_i1 c_12 c_23 c_13 p123 p13 =>
        rcases lem_exactBridgeCert_outcome_dichotomy T ρ_i c_i1 c_12 c_23 c_13 p123 p13 with hex | ⟨r, hr⟩
        · rw [hdisc] at hex; contradiction
        · rw [hdisc] at hr; contradiction
    | emptyOverlapCert emptyCert =>
        unfold auditTriangle2Cell at hdisc
        by_cases hwu : !checkTriangleWiringAndUnits T
        · simp [hwu] at hdisc
        · simp only [hwu, Bool.false_eq_true, ↓reduceIte] at hdisc
          by_cases ha : !checkTriangleAuthorities T
          · simp [ha] at hdisc
          · simp only [ha, Bool.false_eq_true, ↓reduceIte] at hdisc
            cases hce : checkEmptyOverlapCert T.C123 emptyCert <;> simp [hce] at hdisc
    | bridgeDomainViolationCert ρ_viol =>
        unfold auditTriangle2Cell at hdisc
        by_cases hwu : !checkTriangleWiringAndUnits T
        · simp [hwu] at hdisc
        · simp only [hwu, Bool.false_eq_true, ↓reduceIte] at hdisc
          by_cases ha : !checkTriangleAuthorities T
          · simp [ha] at hdisc
          · simp only [ha, Bool.false_eq_true, ↓reduceIte] at hdisc
            cases hv : checkValidDomainQ0 ρ_viol T.C123 && (checkAllStepsValidAt ρ_viol T).isNone <;>
              simp [hv] at hdisc
    | pathDiscrepancyCert ρ_star =>
        unfold auditTriangle2Cell at hdisc
        cases hwu : checkTriangleWiringAndUnits T with
        | false => simp [hwu] at hdisc
        | true =>
          simp only [hwu, Bool.not_true, Bool.false_eq_true, ↓reduceIte] at hdisc
          cases hauth : checkTriangleAuthorities T with
          | false => simp [hauth] at hdisc
          | true =>
            simp only [hauth, Bool.not_true, Bool.false_eq_true, ↓reduceIte] at hdisc
            by_cases hv : !checkValidDomainQ0 ρ_star T.C123
            · simp [hv] at hdisc
            · simp only [hv, Bool.false_eq_true, ↓reduceIte] at hdisc
              have hvalid : ValidDomainQ0 ρ_star T.C123 := by
                cases hb : checkValidDomainQ0 ρ_star T.C123
                · simp [hb] at hv
                · exact (lem_checkValidDomain_iff ρ_star T.C123).mp hb
              cases hst : checkAllStepsValidAt ρ_star T with
              | none => rw [hst] at hdisc; contradiction
              | some pair =>
                  rcases pair with ⟨vc, vd⟩
                  rw [hst] at hdisc; dsimp only at hdisc
                  by_cases hne : vc != vd
                  · have hne' : vc ≠ vd := by simp [bne_iff_ne] at hne; exact hne
                    rcases lem_checkAllStepsValidAt_denote T ρ_star vc vd hwu hst with ⟨hdc, hdd⟩
                    exact ⟨ρ_star, vc, vd, hvalid, hst, hdc, hdd, hne'⟩
                  · simp [hne] at hdisc
  rcases h with ⟨ρ_star, vc, vd, hvalid, hst, hdc, hdd, hne⟩
  have hnot_strong : ¬ StrongEq ρ_star (compositeExpr T) (directExpr T) := by
    rintro ⟨v, h1, h2⟩
    rw [hdc] at h1; rw [hdd] at h2
    injection h1 with h1'; injection h2 with h2'
    exact hne (h1'.trans h2'.symm)
  refine ⟨⟨ρ_star, vc, vd, hvalid, hst, hdc, hdd, hne, hnot_strong⟩, ?_⟩
  intro w_any hexact
  rcases (thm_stageB_exact_bridge_sound T w_any hexact).2.2.2.2 ρ_star hvalid with ⟨v, hst_eq⟩
  rw [hst] at hst_eq
  simp only [Option.some.injEq, Prod.mk.injEq] at hst_eq
  exact hne (hst_eq.1.trans hst_eq.2.symm)

/-- Target Theorem `THM-STAGEB-03` (`thm_stageB_empty_overlap_sound_and_exclusive`):
    `auditTriangle2Cell T w = .verifiedEmptyOverlap` proves `∀ ρ, ¬ ValidDomainQ0 ρ T.C123`
    AND makes `.verifiedExactBridge`, `.verifiedPathDiscrepancy`, and
    `.verifiedBridgeDomainViolation` mathematically impossible for ALL witnesses! -/
theorem thm_stageB_empty_overlap_sound_and_exclusive
    (T : Triangle2CellSpecQ0) (w : Triangle2CellWitnessQ0)
    (hemp : auditTriangle2Cell T w = .verifiedEmptyOverlap) :
    (∀ ρ : List Rat, ¬ ValidDomainQ0 ρ T.C123) ∧
    (∀ w_any : Triangle2CellWitnessQ0,
      auditTriangle2Cell T w_any ≠ .verifiedExactBridge ∧
      auditTriangle2Cell T w_any ≠ .verifiedPathDiscrepancy) := by
  have hempty_all : ∀ ρ : List Rat, ¬ ValidDomainQ0 ρ T.C123 := by
    cases w with
    | exactBridgeCert ρ_i c_i1 c_12 c_23 c_13 p123 p13 =>
        rcases lem_exactBridgeCert_outcome_dichotomy T ρ_i c_i1 c_12 c_23 c_13 p123 p13 with hex | ⟨r, hr⟩
        · rw [hemp] at hex; contradiction
        · rw [hemp] at hr; contradiction
    | pathDiscrepancyCert ρ_star =>
        unfold auditTriangle2Cell at hemp
        by_cases hwu : !checkTriangleWiringAndUnits T
        · simp [hwu] at hemp
        · simp only [hwu, Bool.false_eq_true, ↓reduceIte] at hemp
          by_cases ha : !checkTriangleAuthorities T
          · simp [ha] at hemp
          · simp only [ha, Bool.false_eq_true, ↓reduceIte] at hemp
            by_cases hv : !checkValidDomainQ0 ρ_star T.C123
            · simp [hv] at hemp
            · simp only [hv, Bool.false_eq_true, ↓reduceIte] at hemp
              cases hst : checkAllStepsValidAt ρ_star T with
              | none => rw [hst] at hemp; contradiction
              | some pair =>
                  rcases pair with ⟨vc, vd⟩
                  rw [hst] at hemp; dsimp only at hemp
                  by_cases hne : vc != vd <;> simp [hne] at hemp
    | bridgeDomainViolationCert ρ_viol =>
        unfold auditTriangle2Cell at hemp
        by_cases hwu : !checkTriangleWiringAndUnits T
        · simp [hwu] at hemp
        · simp only [hwu, Bool.false_eq_true, ↓reduceIte] at hemp
          by_cases ha : !checkTriangleAuthorities T
          · simp [ha] at hemp
          · simp only [ha, Bool.false_eq_true, ↓reduceIte] at hemp
            cases hv : checkValidDomainQ0 ρ_viol T.C123 && (checkAllStepsValidAt ρ_viol T).isNone <;>
              simp [hv] at hemp
    | emptyOverlapCert emptyCert =>
        unfold auditTriangle2Cell at hemp
        by_cases hwu : !checkTriangleWiringAndUnits T
        · simp [hwu] at hemp
        · simp only [hwu, Bool.false_eq_true, ↓reduceIte] at hemp
          by_cases ha : !checkTriangleAuthorities T
          · simp [ha] at hemp
          · simp only [ha, Bool.false_eq_true, ↓reduceIte] at hemp
            cases hce : checkEmptyOverlapCert T.C123 emptyCert with
            | false => simp [hce] at hemp
            | true => exact thm_empty_overlap_sound T.C123 emptyCert hce
  refine ⟨hempty_all, fun w_any => ⟨?_, ?_⟩⟩
  · intro hexact
    rcases (thm_stageB_exact_bridge_sound T w_any hexact).2.2.2.1.1 with ⟨ρ₀, hρ₀⟩
    exact hempty_all ρ₀ hρ₀
  · intro hdisc
    rcases (thm_stageB_path_discrepancy_sound_and_exclusive T w_any hdisc).1 with ⟨ρ_s, _, _, hρ_s, _⟩
    exact hempty_all ρ_s hρ_s

/-- Target Theorem `THM-STAGEB-04` (`thm_stageB_domain_violation_sound_and_exclusive`):
    `auditTriangle2Cell T w = .verifiedBridgeDomainViolation` proves `Real_ℚ(C123) ≠ ∅`
    while at `ρ_viol ∈ Real_ℚ(C123)` an intermediate bridge or observable fails validity,
    excluding BOTH `.verifiedExactBridge` AND `.verifiedEmptyOverlap` for ALL witnesses! -/
theorem thm_stageB_domain_violation_sound_and_exclusive
    (T : Triangle2CellSpecQ0) (w : Triangle2CellWitnessQ0)
    (hviol : auditTriangle2Cell T w = .verifiedBridgeDomainViolation) :
    (∃ ρ_viol : List Rat, ValidDomainQ0 ρ_viol T.C123 ∧ checkAllStepsValidAt ρ_viol T = none) ∧
    (∀ w_any : Triangle2CellWitnessQ0,
      auditTriangle2Cell T w_any ≠ .verifiedExactBridge ∧
      auditTriangle2Cell T w_any ≠ .verifiedEmptyOverlap) := by
  have hex : ∃ ρ_viol : List Rat, ValidDomainQ0 ρ_viol T.C123 ∧ checkAllStepsValidAt ρ_viol T = none := by
    cases w with
    | exactBridgeCert ρ_i c_i1 c_12 c_23 c_13 p123 p13 =>
        rcases lem_exactBridgeCert_outcome_dichotomy T ρ_i c_i1 c_12 c_23 c_13 p123 p13 with hex | ⟨r, hr⟩
        · rw [hviol] at hex; contradiction
        · rw [hviol] at hr; contradiction
    | pathDiscrepancyCert ρ_star =>
        unfold auditTriangle2Cell at hviol
        by_cases hwu : !checkTriangleWiringAndUnits T
        · simp [hwu] at hviol
        · simp only [hwu, Bool.false_eq_true, ↓reduceIte] at hviol
          by_cases ha : !checkTriangleAuthorities T
          · simp [ha] at hviol
          · simp only [ha, Bool.false_eq_true, ↓reduceIte] at hviol
            by_cases hv : !checkValidDomainQ0 ρ_star T.C123
            · simp [hv] at hviol
            · simp only [hv, Bool.false_eq_true, ↓reduceIte] at hviol
              cases hst : checkAllStepsValidAt ρ_star T with
              | none => rw [hst] at hviol; contradiction
              | some pair =>
                  rcases pair with ⟨vc, vd⟩
                  rw [hst] at hviol; dsimp only at hviol
                  by_cases hne : vc != vd <;> simp [hne] at hviol
    | emptyOverlapCert emptyCert =>
        unfold auditTriangle2Cell at hviol
        by_cases hwu : !checkTriangleWiringAndUnits T
        · simp [hwu] at hviol
        · simp only [hwu, Bool.false_eq_true, ↓reduceIte] at hviol
          by_cases ha : !checkTriangleAuthorities T
          · simp [ha] at hviol
          · simp only [ha, Bool.false_eq_true, ↓reduceIte] at hviol
            cases hce : checkEmptyOverlapCert T.C123 emptyCert <;> simp [hce] at hviol
    | bridgeDomainViolationCert ρ_viol =>
        unfold auditTriangle2Cell at hviol
        by_cases hwu : !checkTriangleWiringAndUnits T
        · simp [hwu] at hviol
        · simp only [hwu, Bool.false_eq_true, ↓reduceIte] at hviol
          by_cases ha : !checkTriangleAuthorities T
          · simp [ha] at hviol
          · simp only [ha, Bool.false_eq_true, ↓reduceIte] at hviol
            cases hv : checkValidDomainQ0 ρ_viol T.C123 && (checkAllStepsValidAt ρ_viol T).isNone with
            | false => simp [hv] at hviol
            | true =>
                simp only [Bool.and_eq_true, Option.isNone_iff_eq_none] at hv
                exact ⟨ρ_viol, (lem_checkValidDomain_iff ρ_viol T.C123).mp hv.1, hv.2⟩
  rcases hex with ⟨ρ_viol, hvalid, hnone⟩
  refine ⟨⟨ρ_viol, hvalid, hnone⟩, fun w_any => ⟨?_, ?_⟩⟩
  · intro hexact
    rcases (thm_stageB_exact_bridge_sound T w_any hexact).2.2.2.2 ρ_viol hvalid with ⟨v, hsome⟩
    rw [hnone] at hsome
    contradiction
  · intro hemp
    have hno := (thm_stageB_empty_overlap_sound_and_exclusive T w_any hemp).1
    exact hno ρ_viol hvalid

/-! ### Part 5: Exact 2-Cell Rational Defect Calculus & Formal Polynomial Order (`Tribunal 2.D`) -/

/-- Exact 2-cell path residual expression `Δ_123 := compositeExpr T - directExpr T`. -/
def defectExpr (T : Triangle2CellSpecQ0) : ExprQ0 :=
  .binOp .sub (compositeExpr T) (directExpr T)

/-- Reflect the 2-cell defect expression into canonical numerator/denominator `GPRResultQ0`. -/
def compute2CellDefect (T : Triangle2CellSpecQ0) : Option GPRResultQ0 :=
  match reflectExpr T.C123.vars (defectExpr T) with
  | none => none
  | some r =>
      some { num    := canonPoly r.num
             den    := canonPoly r.den
             guards := r.guards
             unit   := r.unit }

/-- Target Theorem `thm_2cell_exact_defect_sound` (`Tribunal Refinement 2.D`):
    Whenever `compute2CellDefect T = some rΔ` and `rΔ.guards` discharge over `T.C123`,
    `evalPoly ρ rΔ.num / evalPoly ρ rΔ.den` is the EXACT closed-form rational difference
    `compositeExpr - directExpr` at EVERY `ρ ∈ Real_ℚ(T.C123)`. -/
theorem thm_2cell_exact_defect_sound
    (T : Triangle2CellSpecQ0) (rΔ : GPRResultQ0) (poleProofs : List BridgeGuardProofQ0)
    (hdef : compute2CellDefect T = some rΔ)
    (hpole : checkBridgeGuardList T.C123.vars T.C123.hyps T.C123.guards poleProofs rΔ.guards = true) :
    ∀ ρ : List Rat, ValidDomainQ0 ρ T.C123 →
      evalPoly ρ rΔ.den ≠ 0 ∧
      denoteExpr ρ (defectExpr T) = some (evalPoly ρ rΔ.num / evalPoly ρ rΔ.den) := by
  unfold compute2CellDefect at hdef
  cases hr : reflectExpr T.C123.vars (defectExpr T) with
  | none => rw [hr] at hdef; contradiction
  | some r =>
      rw [hr] at hdef
      simp only [Option.some.injEq] at hdef
      subst hdef
      intro ρ ⟨henv, hhyps, hguards⟩
      have hg := thm_bridge_guard_list_sound
        T.C123.vars T.C123.hyps T.C123.guards ρ henv hhyps hguards poleProofs r.guards hpole
      rcases thm_gpr_value_sound (defectExpr T) T.C123.vars ρ r henv hr hg with ⟨hden_nz, hval⟩
      simp only [evalPoly_canonPoly]
      exact ⟨hden_nz, hval⟩

/-- Exponent of variable `X_{varIdx}` in monomial `m` (formal multivariate polynomial degree). -/
def monomVarDeg : Nat → Monom → Nat
  | _, []        => 0
  | 0, e :: _    => e
  | s + 1, _ :: es => monomVarDeg s es

/-- Minimum formal degree of variable `X_{varIdx}` across all non-zero terms of `canonPoly p`
    (`none` if `canonPoly p` is the zero polynomial).
    Note (`Tribunal 2.D`): This is the formal polynomial valuation in `ℚ[X_0, …]`, NOT an
    unconditional claim of uniform asymptotic order at degenerate specialized points. -/
def minVarDegTerms (varIdx : Nat) : List (Monom × Rat) → Option Nat
  | [] => none
  | [(m, _)] => some (monomVarDeg varIdx m)
  | (m, _) :: t2 :: rest =>
      match minVarDegTerms varIdx (t2 :: rest) with
      | some dRest => some (Nat.min (monomVarDeg varIdx m) dRest)
      | none       => some (monomVarDeg varIdx m)

def minVarDegPoly (varIdx : Nat) (p : PolyQ0) : Option Nat :=
  minVarDegTerms varIdx (canonPoly p).terms

theorem lem_evalMonom_zero_of_pos_varDeg :
    ∀ (varIdx : Nat) (m : Monom) (ρ : List Rat),
      1 ≤ monomVarDeg varIdx m →
      ρ[varIdx]? = some 0 →
      evalMonom ρ m = 0
  | _, [], _, hdeg, _ => by simp [monomVarDeg] at hdeg
  | 0, e :: es, [], _, hρ => by simp at hρ
  | 0, 0 :: _, _ :: _, hdeg, _ => by simp [monomVarDeg] at hdeg
  | 0, (k + 1) :: es, v :: vs, _, hρ => by
      simp only [List.getElem?_cons_zero, Option.some.injEq] at hρ
      subst hρ
      simp [evalMonom, ratPow, Rat.zero_mul]
  | s + 1, _ :: _, [], _, hρ => by simp at hρ
  | s + 1, e :: es, v :: vs, hdeg, hρ => by
      simp only [monomVarDeg] at hdeg
      simp only [List.getElem?_cons_succ] at hρ
      simp [evalMonom, lem_evalMonom_zero_of_pos_varDeg s es vs hdeg hρ, Rat.mul_zero]

theorem lem_minVarDegTerms_isSome (varIdx : Nat) :
    ∀ (t : Monom × Rat) (ts : List (Monom × Rat)),
      ∃ d : Nat, minVarDegTerms varIdx (t :: ts) = some d
  | (m, _), [] => ⟨monomVarDeg varIdx m, rfl⟩
  | (m, _), t2 :: rest => by
      rcases lem_minVarDegTerms_isSome varIdx t2 rest with ⟨dRest, hd⟩
      exact ⟨Nat.min (monomVarDeg varIdx m) dRest, by simp [minVarDegTerms, hd]⟩

theorem lem_minVarDegTerms_le (varIdx : Nat) :
    ∀ (ts : List (Monom × Rat)) {d : Nat},
      minVarDegTerms varIdx ts = some d →
      ∀ m c, (m, c) ∈ ts → d ≤ monomVarDeg varIdx m
  | [], _, h, _, _, _ => by simp [minVarDegTerms] at h
  | [(m0, c0)], _, h, m, c, hmem => by
      simp only [minVarDegTerms, Option.some.injEq] at h
      simp only [List.mem_singleton, Prod.mk.injEq] at hmem
      rcases hmem with ⟨rfl, rfl⟩
      omega
  | (m1, c1) :: t2 :: rest, d, h, m, c, hmem => by
      simp only [minVarDegTerms] at h
      rcases lem_minVarDegTerms_isSome varIdx t2 rest with ⟨dRest, hsub⟩
      rw [hsub] at h
      simp only [Option.some.injEq] at h
      subst h
      cases List.mem_cons.mp hmem with
      | inl heq =>
          injection heq with hm _
          subst hm
          exact Nat.min_le_left _ _
      | inr htl =>
          have ih := lem_minVarDegTerms_le varIdx (t2 :: rest) hsub m c htl
          exact Nat.le_trans (Nat.min_le_right _ _) ih

/-- Exact Singular-Limit Vanishing Theorem (`thm_poly_vanishes_at_var_zero`):
    If `minVarDegPoly varIdx p = some k` with `1 ≤ k`, then setting `ρ[varIdx] = 0` forces
    `evalPoly ρ p = 0` identically for EVERY assignment to the remaining variables. -/
theorem thm_poly_vanishes_at_var_zero
    (varIdx : Nat) (p : PolyQ0) (k : Nat) (ρ : List Rat)
    (hmin : minVarDegPoly varIdx p = some k)
    (hk : 1 ≤ k)
    (hρ0 : ρ[varIdx]? = some 0) :
    evalPoly ρ p = 0 := by
  have hle := lem_minVarDegTerms_le varIdx (canonPoly p).terms hmin
  rw [← evalPoly_canonPoly ρ p]
  have go : ∀ (ts : List (Monom × Rat)),
      (∀ m c, (m, c) ∈ ts → 1 ≤ monomVarDeg varIdx m) →
      evalTerms ρ ts = 0 := by
    intro ts hts
    induction ts with
    | nil => rfl
    | cons hd tl ih =>
        rcases hd with ⟨m, c⟩
        have hm1 : 1 ≤ monomVarDeg varIdx m := hts m c (by simp)
        have htl : ∀ m' c', (m', c') ∈ tl → 1 ≤ monomVarDeg varIdx m' :=
          fun m' c' hm => hts m' c' (List.mem_cons_of_mem _ hm)
        simp [evalTerms, lem_evalMonom_zero_of_pos_varDeg varIdx m ρ hm1 hρ0,
              ih htl, Rat.mul_zero, Rat.zero_add]
  exact go (canonPoly p).terms (fun m c hm => Nat.le_trans hk (hle m c hm))

end GrandZero.StageB
