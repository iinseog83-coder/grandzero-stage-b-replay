/-
  GRANDZERO Ω — Stage B (Minimal 3-Context · 1-Triangle 2-Cell Certifier)
  Module B-1: Q0ContextAndParallelSubst.lean
  Scope:
    1. Semi-algebraic rational contexts `ContextQ0` & `ValidDomainQ0` (`checkValidDomainQ0`).
    2. Capture-avoiding De Bruijn renaming (`renameExpr`) & Kleisli parallel substitution
       (`substParallel`, `liftCoords`, `substMap`), proving syntactic identity & composition
       laws (`thm_substParallel_id`, `thm_substParallel_comp`, `thm_substMap_comp`).
    3. Strict partial-semantics substitution (`evalCoords`, `lem_substMap_denote`,
       `lem_substGuardMap_eval`, `lem_substPropMap_denote`), strictly separating syntactic
       substitution from total coordinate definedness (`Tribunal Refinement 2.A`).
-/

import StageA

namespace GrandZero.StageB

open GrandZero.StageA

/-! ### Part 1: Semi-Algebraic Contexts `ContextQ0` & `ValidDomainQ0` -/

/-- Well-scopedness of an equality hypothesis within `c` variables. -/
def wellScopedProp (c : Nat) : PropQ0 → Bool
  | .eqProp a b => wellScoped c a && wellScoped c b

/-- Static unit well-typedness of an equality hypothesis under `Γ`. -/
def wellTypedProp (Γ : VarCtxQ0) : PropQ0 → Bool
  | .eqProp a b =>
      match synthUnit Γ a, synthUnit Γ b with
      | some ua, some ub => decide (ua = ub)
      | _, _ => false

theorem wellTypedProp_imp_wellScoped {Γ : VarCtxQ0} {ψ : PropQ0}
    (h : wellTypedProp Γ ψ = true) : wellScopedProp Γ.length ψ = true := by
  cases ψ with
  | eqProp a b =>
      simp only [wellTypedProp] at h
      cases ha : synthUnit Γ a with
      | none => rw [ha] at h; contradiction
      | some ua =>
        cases hb : synthUnit Γ b with
        | none => rw [ha, hb] at h; contradiction
        | some ub =>
          simp [wellScopedProp, synthUnit_imp_wellScoped a ha, synthUnit_imp_wellScoped b hb]

/-- Semi-algebraic rational context `C = (vars, hyps, guards)` over `SIR-Core-Q0`. -/
structure ContextQ0 where
  vars   : VarCtxQ0
  hyps   : HypCtxQ0
  guards : List GuardQ0
  deriving DecidableEq, Repr, Inhabited

/-- Static well-typedness check for a `ContextQ0`. -/
def wellTypedContext (C : ContextQ0) : Bool :=
  C.hyps.all (wellTypedProp C.vars) &&
  C.guards.all (fun ω => (synthUnit C.vars (guardExpr ω)).isSome)

/-- Semantic semi-algebraic realization predicate `ρ ∈ Real_ℚ(C)`. -/
def ValidDomainQ0 (ρ : List Rat) (C : ContextQ0) : Prop :=
  EnvModelsCtx ρ C.vars ∧ HypsHold ρ C.hyps ∧ GuardsHold ρ C.guards

/-- Computable boolean checker for `ValidDomainQ0`. -/
def checkValidDomainQ0 (ρ : List Rat) (C : ContextQ0) : Bool :=
  envModelsCtxBool ρ C.vars && hypsHoldBool ρ C.hyps && guardsHoldBool ρ C.guards

theorem lem_checkValidDomain_iff (ρ : List Rat) (C : ContextQ0) :
    checkValidDomainQ0 ρ C = true ↔ ValidDomainQ0 ρ C := by
  unfold checkValidDomainQ0 ValidDomainQ0
  simp only [Bool.and_eq_true, envModelsCtxBool_iff, hypsHoldBool_iff, guardsHoldBool_iff]
  exact ⟨fun ⟨⟨h1, h2⟩, h3⟩ => ⟨h1, h2, h3⟩, fun ⟨h1, h2, h3⟩ => ⟨⟨h1, h2⟩, h3⟩⟩

/-! ### Part 2: Structural De Bruijn Renaming (`renameExpr`) & Functoriality -/

/-- Lift a variable renaming under one `letBind` binder. -/
def liftRen (ξ : Nat → Nat) : Nat → Nat
  | 0     => 0
  | i + 1 => ξ i + 1

/-- Pure structural De Bruijn variable renaming. -/
def renameExpr (ξ : Nat → Nat) : ExprQ0 → ExprQ0
  | .bvar i       => .bvar (ξ i)
  | .ratLit q u   => .ratLit q u
  | .unaryNeg a   => .unaryNeg (renameExpr ξ a)
  | .binOp op a b => .binOp op (renameExpr ξ a) (renameExpr ξ b)
  | .letBind v b  => .letBind (renameExpr ξ v) (renameExpr (liftRen ξ) b)

theorem liftRen_ext {ξ₁ ξ₂ : Nat → Nat} (h : ∀ i, ξ₁ i = ξ₂ i) :
    ∀ i, liftRen ξ₁ i = liftRen ξ₂ i
  | 0     => rfl
  | i + 1 => congrArg (· + 1) (h i)

theorem renameExpr_ext :
    ∀ (e : ExprQ0) {ξ₁ ξ₂ : Nat → Nat},
      (∀ i, ξ₁ i = ξ₂ i) → renameExpr ξ₁ e = renameExpr ξ₂ e
  | .bvar i, _, _, h       => congrArg ExprQ0.bvar (h i)
  | .ratLit _ _, _, _, _   => rfl
  | .unaryNeg a, _, _, h   => congrArg ExprQ0.unaryNeg (renameExpr_ext a h)
  | .binOp op a b, _, _, h => by
      simp [renameExpr, renameExpr_ext a h, renameExpr_ext b h]
  | .letBind v b, _, _, h  => by
      simp only [renameExpr, renameExpr_ext v h, renameExpr_ext b (liftRen_ext h)]

theorem liftRen_id : ∀ i, liftRen id i = id i
  | 0     => rfl
  | _ + 1 => rfl

/-- Syntactic Functor Identity Law for `renameExpr`. -/
theorem thm_rename_id : ∀ (e : ExprQ0), renameExpr id e = e
  | .bvar _       => rfl
  | .ratLit _ _   => rfl
  | .unaryNeg a   => congrArg ExprQ0.unaryNeg (thm_rename_id a)
  | .binOp op a b => by simp [renameExpr, thm_rename_id a, thm_rename_id b]
  | .letBind v b  => by
      simp only [renameExpr, thm_rename_id v, renameExpr_ext b liftRen_id, thm_rename_id b]

theorem liftRen_comp (ξ₂ ξ₁ : Nat → Nat) :
    ∀ i, liftRen ξ₂ (liftRen ξ₁ i) = liftRen (fun k => ξ₂ (ξ₁ k)) i
  | 0     => rfl
  | _ + 1 => rfl

/-- Syntactic Functor Composition Law for `renameExpr`. -/
theorem thm_rename_comp :
    ∀ (e : ExprQ0) (ξ₂ ξ₁ : Nat → Nat),
      renameExpr ξ₂ (renameExpr ξ₁ e) = renameExpr (fun i => ξ₂ (ξ₁ i)) e
  | .bvar _, _, _       => rfl
  | .ratLit _ _, _, _   => rfl
  | .unaryNeg a, ξ₂, ξ₁ => congrArg ExprQ0.unaryNeg (thm_rename_comp a ξ₂ ξ₁)
  | .binOp op a b, ξ₂, ξ₁ => by
      simp [renameExpr, thm_rename_comp a ξ₂ ξ₁, thm_rename_comp b ξ₂ ξ₁]
  | .letBind v b, ξ₂, ξ₁ => by
      simp only [renameExpr, thm_rename_comp v ξ₂ ξ₁, thm_rename_comp b (liftRen ξ₂) (liftRen ξ₁),
                 renameExpr_ext b (liftRen_comp ξ₂ ξ₁)]

theorem wellScoped_renameExpr :
    ∀ (e : ExprQ0) {c_dst c_src : Nat} {ξ : Nat → Nat},
      (∀ i < c_dst, ξ i < c_src) →
      wellScoped c_dst e = true →
      wellScoped c_src (renameExpr ξ e) = true
  | .bvar i, _, _, _, hξ, hw => by
      simp only [wellScoped, decide_eq_true_eq] at hw
      simp [renameExpr, wellScoped, hξ i hw]
  | .ratLit _ _, _, _, _, _, _ => rfl
  | .unaryNeg a, _, _, _, hξ, hw => wellScoped_renameExpr a hξ hw
  | .binOp _ a b, _, _, _, hξ, hw => by
      simp only [wellScoped, Bool.and_eq_true] at hw
      simp [renameExpr, wellScoped, wellScoped_renameExpr a hξ hw.1, wellScoped_renameExpr b hξ hw.2]
  | .letBind v b, c_dst, c_src, ξ, hξ, hw => by
      simp only [wellScoped, Bool.and_eq_true] at hw
      have hξ' : ∀ i < c_dst + 1, liftRen ξ i < c_src + 1 := by
        intro i hi
        cases i with
        | zero => simp [liftRen]
        | succ j =>
            have hj : j < c_dst := by omega
            have h1 := hξ j hj
            simp only [liftRen]
            omega
      simp [renameExpr, wellScoped, wellScoped_renameExpr v hξ hw.1, wellScoped_renameExpr b hξ' hw.2]

theorem synthUnit_renameExpr :
    ∀ (e : ExprQ0) {Γ_src Γ_dst : VarCtxQ0} {ξ : Nat → Nat},
      (∀ i, Γ_src[ξ i]? = Γ_dst[i]?) →
      synthUnit Γ_src (renameExpr ξ e) = synthUnit Γ_dst e
  | .bvar i, _, _, _, hΓ       => by simp [renameExpr, synthUnit, hΓ i]
  | .ratLit _ _, _, _, _, _    => rfl
  | .unaryNeg a, _, _, _, hΓ   => synthUnit_renameExpr a hΓ
  | .binOp _ a b, _, _, _, hΓ  => by
      simp [renameExpr, synthUnit, synthUnit_renameExpr a hΓ, synthUnit_renameExpr b hΓ]
  | .letBind v b, Γ_src, Γ_dst, ξ, hΓ => by
      simp only [renameExpr, synthUnit, synthUnit_renameExpr v hΓ]
      cases synthUnit Γ_dst v with
      | none => rfl
      | some uv =>
          have hΓ' : ∀ i, (uv :: Γ_src)[liftRen ξ i]? = (uv :: Γ_dst)[i]? := by
            intro i
            cases i with
            | zero => rfl
            | succ j => simpa [liftRen] using hΓ j
          exact synthUnit_renameExpr b hΓ'

theorem synthUnit_rename_succ (u₀ : UnitSpecQ0) (Γ : VarCtxQ0) (e : ExprQ0) :
    synthUnit (u₀ :: Γ) (renameExpr Nat.succ e) = synthUnit Γ e :=
  synthUnit_renameExpr e (fun _ => rfl)

theorem denoteExpr_renameExpr :
    ∀ (e : ExprQ0) {ρ_src ρ_dst : List Rat} {ξ : Nat → Nat},
      (∀ i, ρ_src[ξ i]? = ρ_dst[i]?) →
      denoteExpr ρ_src (renameExpr ξ e) = denoteExpr ρ_dst e
  | .bvar i, _, _, _, hρ       => by simp [renameExpr, denoteExpr, hρ i]
  | .ratLit _ _, _, _, _, _    => rfl
  | .unaryNeg a, _, _, _, hρ   => by simp [renameExpr, denoteExpr, denoteExpr_renameExpr a hρ]
  | .binOp _ a b, _, _, _, hρ  => by
      simp [renameExpr, denoteExpr, denoteExpr_renameExpr a hρ, denoteExpr_renameExpr b hρ]
  | .letBind v b, ρ_src, ρ_dst, ξ, hρ => by
      simp only [renameExpr, denoteExpr, denoteExpr_renameExpr v hρ]
      cases denoteExpr ρ_dst v with
      | none => rfl
      | some val_v =>
          have hρ' : ∀ i, (val_v :: ρ_src)[liftRen ξ i]? = (val_v :: ρ_dst)[i]? := by
            intro i
            cases i with
            | zero => rfl
            | succ j => simpa [liftRen] using hρ j
          exact denoteExpr_renameExpr b hρ'

theorem denoteExpr_rename_succ (v₀ : Rat) (ρ : List Rat) (e : ExprQ0) :
    denoteExpr (v₀ :: ρ) (renameExpr Nat.succ e) = denoteExpr ρ e :=
  denoteExpr_renameExpr e (fun _ => rfl)

/-! ### Part 3: Capture-Avoiding Kleisli Parallel Substitution (`Tribunal 2.A Part 1`) -/

/-- Lift a parallel substitution across one `letBind` binder (`σ↑`). -/
def liftSubst (σ : Nat → ExprQ0) : Nat → ExprQ0
  | 0     => .bvar 0
  | i + 1 => renameExpr Nat.succ (σ i)

/-- Capture-avoiding parallel De Bruijn substitution. -/
def substParallel (σ : Nat → ExprQ0) : ExprQ0 → ExprQ0
  | .bvar i       => σ i
  | .ratLit q u   => .ratLit q u
  | .unaryNeg a   => .unaryNeg (substParallel σ a)
  | .binOp op a b => .binOp op (substParallel σ a) (substParallel σ b)
  | .letBind v b  => .letBind (substParallel σ v) (substParallel (liftSubst σ) b)

theorem liftSubst_ext {σ₁ σ₂ : Nat → ExprQ0} (h : ∀ i, σ₁ i = σ₂ i) :
    ∀ i, liftSubst σ₁ i = liftSubst σ₂ i
  | 0     => rfl
  | i + 1 => congrArg (renameExpr Nat.succ) (h i)

theorem substParallel_ext :
    ∀ (e : ExprQ0) {σ₁ σ₂ : Nat → ExprQ0},
      (∀ i, σ₁ i = σ₂ i) → substParallel σ₁ e = substParallel σ₂ e
  | .bvar i, _, _, h       => h i
  | .ratLit _ _, _, _, _   => rfl
  | .unaryNeg a, _, _, h   => congrArg ExprQ0.unaryNeg (substParallel_ext a h)
  | .binOp op a b, _, _, h => by
      simp [substParallel, substParallel_ext a h, substParallel_ext b h]
  | .letBind v b, _, _, h  => by
      simp [substParallel, substParallel_ext v h, substParallel_ext b (liftSubst_ext h)]

theorem substParallel_ext_scoped :
    ∀ (e : ExprQ0) {c : Nat} {σ₁ σ₂ : Nat → ExprQ0},
      wellScoped c e = true →
      (∀ i < c, σ₁ i = σ₂ i) →
      substParallel σ₁ e = substParallel σ₂ e
  | .bvar i, _, _, _, hw, h => by
      simp only [wellScoped, decide_eq_true_eq] at hw
      exact h i hw
  | .ratLit _ _, _, _, _, _, _ => rfl
  | .unaryNeg a, _, _, _, hw, h =>
      congrArg ExprQ0.unaryNeg (substParallel_ext_scoped a hw h)
  | .binOp op a b, _, _, _, hw, h => by
      simp only [wellScoped, Bool.and_eq_true] at hw
      simp [substParallel, substParallel_ext_scoped a hw.1 h, substParallel_ext_scoped b hw.2 h]
  | .letBind v b, c, σ₁, σ₂, hw, h => by
      simp only [wellScoped, Bool.and_eq_true] at hw
      have h' : ∀ i < c + 1, liftSubst σ₁ i = liftSubst σ₂ i := by
        intro i hi
        cases i with
        | zero => rfl
        | succ j =>
            have hj : j < c := by omega
            simp [liftSubst, h j hj]
      simp [substParallel, substParallel_ext_scoped v hw.1 h, substParallel_ext_scoped b hw.2 h']

theorem liftSubst_bvar : ∀ i, liftSubst ExprQ0.bvar i = ExprQ0.bvar i
  | 0     => rfl
  | _ + 1 => rfl

/-- Kleisli Syntactic Identity Law: `substParallel bvar e = e`. -/
theorem thm_substParallel_id : ∀ (e : ExprQ0), substParallel ExprQ0.bvar e = e
  | .bvar _       => rfl
  | .ratLit _ _   => rfl
  | .unaryNeg a   => congrArg ExprQ0.unaryNeg (thm_substParallel_id a)
  | .binOp op a b => by simp [substParallel, thm_substParallel_id a, thm_substParallel_id b]
  | .letBind v b  => by
      simp only [substParallel, thm_substParallel_id v,
                 substParallel_ext b liftSubst_bvar, thm_substParallel_id b]

theorem liftRen_comm_liftSubst (ξ : Nat → Nat) (σ : Nat → ExprQ0) :
    ∀ i, renameExpr (liftRen ξ) (liftSubst σ i) = liftSubst (fun k => renameExpr ξ (σ k)) i
  | 0     => rfl
  | i + 1 => by
      simp only [liftSubst, thm_rename_comp]
      exact renameExpr_ext (σ i) (fun _ => rfl)

theorem lem_rename_subst :
    ∀ (e : ExprQ0) (ξ : Nat → Nat) (σ : Nat → ExprQ0),
      renameExpr ξ (substParallel σ e) = substParallel (fun i => renameExpr ξ (σ i)) e
  | .bvar _, _, _       => rfl
  | .ratLit _ _, _, _   => rfl
  | .unaryNeg a, ξ, σ   => congrArg ExprQ0.unaryNeg (lem_rename_subst a ξ σ)
  | .binOp op a b, ξ, σ => by
      simp [substParallel, renameExpr, lem_rename_subst a ξ σ, lem_rename_subst b ξ σ]
  | .letBind v b, ξ, σ  => by
      simp only [substParallel, renameExpr, lem_rename_subst v ξ σ,
                 lem_rename_subst b (liftRen ξ) (liftSubst σ),
                 substParallel_ext b (liftRen_comm_liftSubst ξ σ)]

theorem liftSubst_comp_liftRen (σ : Nat → ExprQ0) (ξ : Nat → Nat) :
    ∀ i, liftSubst σ (liftRen ξ i) = liftSubst (fun k => σ (ξ k)) i
  | 0     => rfl
  | _ + 1 => rfl

theorem lem_subst_rename :
    ∀ (e : ExprQ0) (σ : Nat → ExprQ0) (ξ : Nat → Nat),
      substParallel σ (renameExpr ξ e) = substParallel (fun i => σ (ξ i)) e
  | .bvar _, _, _       => rfl
  | .ratLit _ _, _, _   => rfl
  | .unaryNeg a, σ, ξ   => congrArg ExprQ0.unaryNeg (lem_subst_rename a σ ξ)
  | .binOp op a b, σ, ξ => by
      simp [substParallel, renameExpr, lem_subst_rename a σ ξ, lem_subst_rename b σ ξ]
  | .letBind v b, σ, ξ  => by
      simp only [substParallel, renameExpr, lem_subst_rename v σ ξ,
                 lem_subst_rename b (liftSubst σ) (liftRen ξ),
                 substParallel_ext b (liftSubst_comp_liftRen σ ξ)]

theorem liftSubst_kleisli_comp (τ σ : Nat → ExprQ0) :
    ∀ i, substParallel (liftSubst τ) (liftSubst σ i) =
         liftSubst (fun k => substParallel τ (σ k)) i
  | 0     => rfl
  | i + 1 => by
      simp only [liftSubst, lem_subst_rename, lem_rename_subst]

/-- Kleisli Syntactic Composition Law:
    `substParallel τ (substParallel σ e) = substParallel (τ >=> σ) e`. -/
theorem thm_substParallel_comp :
    ∀ (e : ExprQ0) (τ σ : Nat → ExprQ0),
      substParallel τ (substParallel σ e) = substParallel (fun i => substParallel τ (σ i)) e
  | .bvar _, _, _       => rfl
  | .ratLit _ _, _, _   => rfl
  | .unaryNeg a, τ, σ   => congrArg ExprQ0.unaryNeg (thm_substParallel_comp a τ σ)
  | .binOp op a b, τ, σ => by
      simp [substParallel, thm_substParallel_comp a τ σ, thm_substParallel_comp b τ σ]
  | .letBind v b, τ, σ  => by
      simp only [substParallel, thm_substParallel_comp v τ σ,
                 thm_substParallel_comp b (liftSubst τ) (liftSubst σ),
                 substParallel_ext b (liftSubst_kleisli_comp τ σ)]

/-! ### Part 4: Concrete Coordinate Lists `substMap`, `liftCoords`, & Static Unit Pullback -/

/-- Lift a finite coordinate substitution list across one `letBind` binder:
    `σ↑ = bvar 0 :: map (renameExpr succ) σ` (`Tribunal 2.A`). -/
def liftCoords (coords : List ExprQ0) : List ExprQ0 :=
  .bvar 0 :: coords.map (renameExpr Nat.succ)

/-- Embed a finite coordinate list into a total substitution function. -/
def coordsToSubst (coords : List ExprQ0) (i : Nat) : ExprQ0 :=
  match coords[i]? with
  | some c => c
  | none   => .bvar i

theorem coordsToSubst_liftCoords (coords : List ExprQ0) :
    ∀ i : Nat, coordsToSubst (liftCoords coords) i = liftSubst (coordsToSubst coords) i
  | 0     => rfl
  | i + 1 => by
      unfold liftCoords coordsToSubst liftSubst
      simp only [List.getElem?_cons_succ, List.getElem?_map]
      cases coords[i]? <;> rfl

/-- Parallel coordinate substitution on `ExprQ0`. -/
def substMap (coords : List ExprQ0) (e : ExprQ0) : ExprQ0 :=
  substParallel (coordsToSubst coords) e

@[simp] theorem substMap_bvar (coords : List ExprQ0) (i : Nat) :
    substMap coords (.bvar i) = coordsToSubst coords i := rfl

@[simp] theorem substMap_ratLit (coords : List ExprQ0) (q : Rat) (u : UnitSpecQ0) :
    substMap coords (.ratLit q u) = .ratLit q u := rfl

@[simp] theorem substMap_unaryNeg (coords : List ExprQ0) (a : ExprQ0) :
    substMap coords (.unaryNeg a) = .unaryNeg (substMap coords a) := rfl

@[simp] theorem substMap_binOp (coords : List ExprQ0) (op : BinOpQ0) (a b : ExprQ0) :
    substMap coords (.binOp op a b) = .binOp op (substMap coords a) (substMap coords b) := rfl

@[simp] theorem substMap_letBind (coords : List ExprQ0) (v body : ExprQ0) :
    substMap coords (.letBind v body) =
      .letBind (substMap coords v) (substMap (liftCoords coords) body) := by
  unfold substMap
  simp only [substParallel, substParallel_ext body (coordsToSubst_liftCoords coords)]

/-- Guard coordinate pullback (`f* ω`). -/
def substGuardMap (coords : List ExprQ0) : GuardQ0 → GuardQ0
  | .nonZero d => .nonZero (substMap coords d)
  | .pos d     => .pos     (substMap coords d)
  | .nonNeg d  => .nonNeg  (substMap coords d)

@[simp] theorem guardExpr_substGuardMap (coords : List ExprQ0) (ω : GuardQ0) :
    guardExpr (substGuardMap coords ω) = substMap coords (guardExpr ω) := by
  cases ω <;> rfl

/-- Equality proposition coordinate pullback (`f* ψ`). -/
def substPropMap (coords : List ExprQ0) : PropQ0 → PropQ0
  | .eqProp a b => .eqProp (substMap coords a) (substMap coords b)

/-- Syntactic coordinate map composition (`c1` pulls `C_mid` to `C_src`, `c2` pulls `C_dst` to `C_mid`). -/
def compCoords (c_src_to_mid c_mid_to_dst : List ExprQ0) : List ExprQ0 :=
  c_mid_to_dst.map (substMap c_src_to_mid)

/-- Syntactic Contravariant Composition Law for `substMap` on well-scoped expressions. -/
theorem thm_substMap_comp (e : ExprQ0) (c1 c2 : List ExprQ0)
    (hw : wellScoped c2.length e = true) :
    substMap c1 (substMap c2 e) = substMap (compCoords c1 c2) e := by
  unfold substMap
  rw [thm_substParallel_comp]
  apply substParallel_ext_scoped e hw
  intro i hi
  have hc2 : ∃ expr_i, c2[i]? = some expr_i := ⟨c2[i], List.getElem?_eq_getElem hi⟩
  rcases hc2 with ⟨expr_i, hget⟩
  have hcomp_get : (compCoords c1 c2)[i]? = some (substMap c1 expr_i) := by
    simp [compCoords, List.getElem?_map, hget]
  calc
    substParallel (coordsToSubst c1) (coordsToSubst c2 i)
        = substParallel (coordsToSubst c1) expr_i := by
            simp [coordsToSubst, hget]
    _ = coordsToSubst (compCoords c1 c2) i := by
            simp [coordsToSubst, hcomp_get, substMap]

/-- Identity coordinate vector `[bvar 0, ..., bvar (m - 1)]`. -/
def idCoords (m : Nat) : List ExprQ0 :=
  (List.range m).map ExprQ0.bvar

@[simp] theorem idCoords_length (m : Nat) : (idCoords m).length = m := by
  simp [idCoords]

theorem thm_substMap_idCoords (m : Nat) (e : ExprQ0) (hw : wellScoped m e = true) :
    substMap (idCoords m) e = e := by
  unfold substMap
  have heq : substParallel (coordsToSubst (idCoords m)) e = substParallel ExprQ0.bvar e := by
    apply substParallel_ext_scoped e hw
    intro i hi
    unfold idCoords coordsToSubst
    simp [List.getElem?_map, List.getElem?_range hi]
  rw [heq, thm_substParallel_id]

/-- Scoping preservation under `substMap`. -/
theorem lem_substMap_wellScoped :
    ∀ (e : ExprQ0) {m_src : Nat} {coords : List ExprQ0},
      (∀ c ∈ coords, wellScoped m_src c = true) →
      wellScoped coords.length e = true →
      wellScoped m_src (substMap coords e) = true
  | .bvar i, m_src, coords, hc, hw => by
      simp only [wellScoped, decide_eq_true_eq] at hw
      have hget : coords[i]? = some coords[i] := List.getElem?_eq_getElem hw
      have hmem : coords[i] ∈ coords := List.getElem_mem hw
      simp [substMap_bvar, coordsToSubst, hget, hc coords[i] hmem]
  | .ratLit _ _, _, _, _, _ => rfl
  | .unaryNeg a, _, _, hc, hw => lem_substMap_wellScoped a hc hw
  | .binOp _ a b, _, _, hc, hw => by
      simp only [wellScoped, Bool.and_eq_true] at hw
      simp [substMap_binOp, wellScoped,
            lem_substMap_wellScoped a hc hw.1,
            lem_substMap_wellScoped b hc hw.2]
  | .letBind v b, m_src, coords, hc, hw => by
      simp only [wellScoped, Bool.and_eq_true] at hw
      have hc' : ∀ c' ∈ liftCoords coords, wellScoped (m_src + 1) c' = true := by
        intro c' hm
        simp only [liftCoords, List.mem_cons, List.mem_map] at hm
        rcases hm with rfl | ⟨c0, hmem, rfl⟩
        · simp [wellScoped]
        · exact wellScoped_renameExpr c0 (c_dst := m_src) (fun _ hi => by omega) (hc c0 hmem)
      have hlen : (liftCoords coords).length = coords.length + 1 := by simp [liftCoords]
      have hwb : wellScoped (liftCoords coords).length b = true := by rw [hlen]; exact hw.2
      simp [substMap_letBind, wellScoped,
            lem_substMap_wellScoped v hc hw.1,
            lem_substMap_wellScoped b hc' hwb]

/-- Exact slot-by-slot static `UnitSpecQ0` (`DimVec7` + `KindTagQ0`) match check. -/
def checkCoordsUnits (Γ_src : VarCtxQ0) : List ExprQ0 → VarCtxQ0 → Bool
  | [], [] => true
  | c :: cs, u :: us => (synthUnit Γ_src c == some u) && checkCoordsUnits Γ_src cs us
  | _, _ => false

theorem checkCoordsUnits_length {Γ_src : VarCtxQ0} :
    ∀ {coords : List ExprQ0} {Γ_dst : VarCtxQ0},
      checkCoordsUnits Γ_src coords Γ_dst = true → coords.length = Γ_dst.length
  | [], [], _ => rfl
  | [], _ :: _, h => by simp [checkCoordsUnits] at h
  | _ :: _, [], h => by simp [checkCoordsUnits] at h
  | _ :: cs, _ :: us, h => by
      simp only [checkCoordsUnits, Bool.and_eq_true] at h
      simp [checkCoordsUnits_length h.2]

theorem checkCoordsUnits_wellScoped {Γ_src : VarCtxQ0} :
    ∀ {coords : List ExprQ0} {Γ_dst : VarCtxQ0},
      checkCoordsUnits Γ_src coords Γ_dst = true →
      ∀ c ∈ coords, wellScoped Γ_src.length c = true
  | [], [], _, _, hm => by simp at hm
  | [], _ :: _, h, _, _ => by simp [checkCoordsUnits] at h
  | _ :: _, [], h, _, _ => by simp [checkCoordsUnits] at h
  | c :: cs, u :: us, h, x, hm => by
      simp only [checkCoordsUnits, Bool.and_eq_true, beq_iff_eq] at h
      cases List.mem_cons.mp hm with
      | inl heq => subst heq; exact synthUnit_imp_wellScoped x h.1
      | inr htl => exact checkCoordsUnits_wellScoped h.2 x htl

theorem checkCoordsUnits_getElem {Γ_src : VarCtxQ0} :
    ∀ {coords : List ExprQ0} {Γ_dst : VarCtxQ0},
      checkCoordsUnits Γ_src coords Γ_dst = true →
      ∀ (i : Nat), i < Γ_dst.length →
        ∃ c u, coords[i]? = some c ∧ Γ_dst[i]? = some u ∧ synthUnit Γ_src c = some u
  | [], [], _, _, hi => by simp at hi
  | [], _ :: _, h, _, _ => by simp [checkCoordsUnits] at h
  | _ :: _, [], h, _, _ => by simp [checkCoordsUnits] at h
  | c :: cs, u :: us, h, 0, _ => by
      simp only [checkCoordsUnits, Bool.and_eq_true, beq_iff_eq] at h
      exact ⟨c, u, rfl, rfl, h.1⟩
  | _ :: cs, _ :: us, h, i + 1, hi => by
      simp only [checkCoordsUnits, Bool.and_eq_true] at h
      have hi' : i < us.length := by simp at hi; omega
      exact checkCoordsUnits_getElem h.2 i hi'

theorem checkCoordsUnits_liftCoords {Γ_src : VarCtxQ0} {coords : List ExprQ0} {Γ_dst : VarCtxQ0}
    (uv : UnitSpecQ0) (h : checkCoordsUnits Γ_src coords Γ_dst = true) :
    checkCoordsUnits (uv :: Γ_src) (liftCoords coords) (uv :: Γ_dst) = true := by
  have go : ∀ {cs : List ExprQ0} {us : VarCtxQ0},
      checkCoordsUnits Γ_src cs us = true →
      checkCoordsUnits (uv :: Γ_src) (cs.map (renameExpr Nat.succ)) us = true := by
    intro cs us hcs
    induction cs generalizing us with
    | nil =>
        cases us with
        | nil => rfl
        | cons _ _ => simp [checkCoordsUnits] at hcs
    | cons c rest ih =>
        cases us with
        | nil => simp [checkCoordsUnits] at hcs
        | cons u urest =>
            simp only [List.map_cons, checkCoordsUnits, Bool.and_eq_true, beq_iff_eq] at hcs ⊢
            exact ⟨by rw [synthUnit_rename_succ, hcs.1], ih hcs.2⟩
  unfold liftCoords checkCoordsUnits
  simp only [synthUnit, List.getElem?_cons_zero, beq_self_eq_true, Bool.true_and]
  exact go h

/-- Static Unit Preservation under Parallel Coordinate Substitution:
    Every well-scoped expression over `Γ_dst` preserves its exact `UnitSpecQ0` (`DimVec7` + `KindTagQ0`). -/
theorem lem_substMap_unit :
    ∀ (e : ExprQ0) {Γ_src Γ_dst : VarCtxQ0} {coords : List ExprQ0},
      checkCoordsUnits Γ_src coords Γ_dst = true →
      wellScoped Γ_dst.length e = true →
      synthUnit Γ_src (substMap coords e) = synthUnit Γ_dst e
  | .bvar i, Γ_src, Γ_dst, coords, hc, hw => by
      simp only [wellScoped, decide_eq_true_eq] at hw
      rcases checkCoordsUnits_getElem hc i hw with ⟨c, u, hc_get, hu_get, hsu⟩
      simp [substMap_bvar, coordsToSubst, hc_get, synthUnit, hu_get, hsu]
  | .ratLit _ _, _, _, _, _, _ => rfl
  | .unaryNeg a, _, _, _, hc, hw => lem_substMap_unit a hc hw
  | .binOp _ a b, _, _, _, hc, hw => by
      simp only [wellScoped, Bool.and_eq_true] at hw
      simp [substMap_binOp, synthUnit,
            lem_substMap_unit a hc hw.1,
            lem_substMap_unit b hc hw.2]
  | .letBind v body, Γ_src, Γ_dst, coords, hc, hw => by
      simp only [wellScoped, Bool.and_eq_true] at hw
      simp only [substMap_letBind, synthUnit, lem_substMap_unit v hc hw.1]
      cases synthUnit Γ_dst v with
      | none => rfl
      | some uv =>
          have hc' := checkCoordsUnits_liftCoords uv hc
          have hwb : wellScoped (uv :: Γ_dst).length body = true := hw.2
          exact lem_substMap_unit body hc' hwb

theorem lem_substGuardMap_unit {Γ_src Γ_dst : VarCtxQ0} {coords : List ExprQ0}
    (hc : checkCoordsUnits Γ_src coords Γ_dst = true) (ω : GuardQ0)
    (hw : wellScoped Γ_dst.length (guardExpr ω) = true) :
    synthUnit Γ_src (guardExpr (substGuardMap coords ω)) = synthUnit Γ_dst (guardExpr ω) := by
  rw [guardExpr_substGuardMap]
  exact lem_substMap_unit (guardExpr ω) hc hw

/-! ### Part 5: Strict Partial-Semantics Coordinate Evaluation (`Tribunal 2.A Part 2`) -/

/-- Strict total coordinate evaluation: yields `some ρ'` iff EVERY coordinate expression
    in `coords` evaluates to `some v` (even coordinates unused by a particular target formula). -/
def evalCoords (ρ : List Rat) : List ExprQ0 → Option (List Rat)
  | []      => some []
  | c :: cs =>
      match denoteExpr ρ c, evalCoords ρ cs with
      | some v, some vs => some (v :: vs)
      | _, _            => none

theorem evalCoords_length {ρ : List Rat} :
    ∀ {coords : List ExprQ0} {ρ' : List Rat},
      evalCoords ρ coords = some ρ' → ρ'.length = coords.length
  | [], _, h => by simp only [evalCoords, Option.some.injEq] at h; subst h; rfl
  | c :: cs, _, h => by
      unfold evalCoords at h
      cases hc : denoteExpr ρ c with
      | none => rw [hc] at h; contradiction
      | some v =>
        cases hcs : evalCoords ρ cs with
        | none => rw [hc, hcs] at h; contradiction
        | some vs =>
          rw [hc, hcs] at h
          simp only [Option.some.injEq] at h
          subst h
          simp [evalCoords_length hcs]

theorem evalCoords_getElem {ρ : List Rat} :
    ∀ {coords : List ExprQ0} {ρ' : List Rat},
      evalCoords ρ coords = some ρ' →
      ∀ (i : Nat), i < coords.length →
        ∃ c v, coords[i]? = some c ∧ ρ'[i]? = some v ∧ denoteExpr ρ c = some v
  | [], _, _, _, hi => by simp at hi
  | c :: cs, _, h, 0, _ => by
      unfold evalCoords at h
      cases hc : denoteExpr ρ c with
      | none => rw [hc] at h; contradiction
      | some v =>
        cases hcs : evalCoords ρ cs with
        | none => rw [hc, hcs] at h; contradiction
        | some vs =>
          rw [hc, hcs] at h
          simp only [Option.some.injEq] at h
          subst h
          exact ⟨c, v, rfl, rfl, hc⟩
  | c :: cs, _, h, i + 1, hi => by
      unfold evalCoords at h
      cases hc : denoteExpr ρ c with
      | none => rw [hc] at h; contradiction
      | some v =>
        cases hcs : evalCoords ρ cs with
        | none => rw [hc, hcs] at h; contradiction
        | some vs =>
          rw [hc, hcs] at h
          simp only [Option.some.injEq] at h
          subst h
          have hi' : i < cs.length := by simp at hi; omega
          exact evalCoords_getElem hcs i hi'

theorem evalCoords_liftCoords {ρ ρ' : List Rat} {coords : List ExprQ0}
    (v₀ : Rat) (h : evalCoords ρ coords = some ρ') :
    evalCoords (v₀ :: ρ) (liftCoords coords) = some (v₀ :: ρ') := by
  have go : ∀ {cs : List ExprQ0} {vs : List Rat},
      evalCoords ρ cs = some vs →
      evalCoords (v₀ :: ρ) (cs.map (renameExpr Nat.succ)) = some vs := by
    intro cs vs hcs
    induction cs generalizing vs with
    | nil =>
        simp only [evalCoords, Option.some.injEq] at hcs
        subst hcs
        rfl
    | cons c rest ih =>
        unfold evalCoords at hcs
        cases hc : denoteExpr ρ c with
        | none => rw [hc] at hcs; contradiction
        | some vc =>
          cases hrest : evalCoords ρ rest with
          | none => rw [hc, hrest] at hcs; contradiction
          | some vrest =>
            rw [hc, hrest] at hcs
            simp only [Option.some.injEq] at hcs
            subst hcs
            simp only [List.map_cons, evalCoords, denoteExpr_rename_succ, hc, ih hrest]
  unfold liftCoords evalCoords
  simp only [denoteExpr, List.getElem?_cons_zero, go h]

/-- Semantic Substitution Law (`Tribunal 2.A Part 2`):
    PROVIDED `evalCoords ρ coords = some ρ'` (all coordinate expressions are defined at `ρ`),
    evaluating `substMap coords e` at `ρ` equals evaluating `e` at `ρ'` under strict `Option Rat` semantics. -/
theorem lem_substMap_denote :
    ∀ (e : ExprQ0) {ρ ρ' : List Rat} {coords : List ExprQ0},
      evalCoords ρ coords = some ρ' →
      wellScoped coords.length e = true →
      denoteExpr ρ (substMap coords e) = denoteExpr ρ' e
  | .bvar i, ρ, ρ', coords, hev, hw => by
      simp only [wellScoped, decide_eq_true_eq] at hw
      rcases evalCoords_getElem hev i hw with ⟨c, v, hc_get, hv_get, hdc⟩
      simp [substMap_bvar, coordsToSubst, hc_get, denoteExpr, hv_get, hdc]
  | .ratLit _ _, _, _, _, _, _ => rfl
  | .unaryNeg a, _, _, _, hev, hw => by
      simp [substMap_unaryNeg, denoteExpr, lem_substMap_denote a hev hw]
  | .binOp _ a b, _, _, _, hev, hw => by
      simp only [wellScoped, Bool.and_eq_true] at hw
      simp [substMap_binOp, denoteExpr,
            lem_substMap_denote a hev hw.1,
            lem_substMap_denote b hev hw.2]
  | .letBind v body, ρ, ρ', coords, hev, hw => by
      simp only [wellScoped, Bool.and_eq_true] at hw
      simp only [substMap_letBind, denoteExpr, lem_substMap_denote v hev hw.1]
      cases denoteExpr ρ' v with
      | none => rfl
      | some val_v =>
          have hev' := evalCoords_liftCoords val_v hev
          have hlen : (liftCoords coords).length = coords.length + 1 := by simp [liftCoords]
          have hwb : wellScoped (liftCoords coords).length body = true := by rw [hlen]; exact hw.2
          exact lem_substMap_denote body hev' hwb

theorem lem_substGuardMap_eval {ρ ρ' : List Rat} {coords : List ExprQ0}
    (hev : evalCoords ρ coords = some ρ') (ω : GuardQ0)
    (hw : wellScoped coords.length (guardExpr ω) = true) :
    evalGuard ρ (substGuardMap coords ω) = evalGuard ρ' ω := by
  cases ω with
  | nonZero d =>
      simp only [substGuardMap, evalGuard, lem_substMap_denote d hev hw]
  | pos d =>
      simp only [substGuardMap, evalGuard, lem_substMap_denote d hev hw]
  | nonNeg d =>
      simp only [substGuardMap, evalGuard, lem_substMap_denote d hev hw]

theorem lem_substPropMap_denote {ρ ρ' : List Rat} {coords : List ExprQ0}
    (hev : evalCoords ρ coords = some ρ') (ψ : PropQ0)
    (hw : wellScopedProp coords.length ψ = true) :
    denoteProp ρ (substPropMap coords ψ) = denoteProp ρ' ψ := by
  cases ψ with
  | eqProp a b =>
      simp only [wellScopedProp, Bool.and_eq_true] at hw
      simp only [substPropMap, denoteProp,
                 lem_substMap_denote a hev hw.1,
                 lem_substMap_denote b hev hw.2]

/-- Semantic Composition of `evalCoords` along `compCoords`. -/
theorem lem_evalCoords_compCoords {ρ₁ ρ₂ ρ₃ : List Rat} {c1 c2 : List ExprQ0}
    (hw2 : ∀ c ∈ c2, wellScoped c1.length c = true)
    (h1 : evalCoords ρ₁ c1 = some ρ₂)
    (h2 : evalCoords ρ₂ c2 = some ρ₃) :
    evalCoords ρ₁ (compCoords c1 c2) = some ρ₃ := by
  induction c2 generalizing ρ₃ with
  | nil =>
      simp only [evalCoords, Option.some.injEq] at h2
      subst h2
      rfl
  | cons c rest ih =>
      have hwc : wellScoped c1.length c = true := hw2 c (by simp)
      have hwrest : ∀ x ∈ rest, wellScoped c1.length x = true :=
        fun x hx => hw2 x (List.mem_cons_of_mem _ hx)
      unfold evalCoords at h2
      cases hc : denoteExpr ρ₂ c with
      | none => rw [hc] at h2; contradiction
      | some vc =>
        cases hrest : evalCoords ρ₂ rest with
        | none => rw [hc, hrest] at h2; contradiction
        | some vrest =>
          rw [hc, hrest] at h2
          simp only [Option.some.injEq] at h2
          subst h2
          have ih' : evalCoords ρ₁ (rest.map (substMap c1)) = some vrest := ih hwrest hrest
          simp only [compCoords, List.map_cons, evalCoords,
                     lem_substMap_denote c h1 hwc, hc, ih']

/-- Mechanized Strictness Boundary Witness (`Tribunal 2.A`):
    An unused undefined coordinate `1 / 0` does NOT affect pure syntactic substitution into
    constant `5`, yet `evalCoords` strictly evaluates to `none` (matching strict `letBind`). -/
theorem thm_unused_undefined_coord_strict_difference :
    let undefCoord := ExprQ0.binOp .div (.ratLit 1 .unitless) (.ratLit 0 .unitless)
    let constFive  := ExprQ0.ratLit 5 .unitless
    denoteExpr [] (substMap [undefCoord] constFive) = some 5 ∧
    evalCoords [] [undefCoord] = none ∧
    denoteExpr [] (.letBind undefCoord constFive) = none := by
  refine ⟨by with_unfolding_all rfl, by with_unfolding_all rfl, by with_unfolding_all rfl⟩

end GrandZero.StageB
